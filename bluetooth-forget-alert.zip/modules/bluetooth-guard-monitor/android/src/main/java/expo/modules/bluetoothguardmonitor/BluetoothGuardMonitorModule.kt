package expo.modules.bluetoothguardmonitor

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import expo.modules.kotlin.Promise
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class BluetoothGuardMonitorModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("BluetoothGuardMonitor")

    AsyncFunction("getPairedDevices") { promise: Promise ->
      val context = appContext.reactContext
      if (context == null) {
        promise.reject("CONTEXT_UNAVAILABLE", "لم يتهيأ سياق Android بعد", null)
        return@AsyncFunction
      }
      if (!hasBluetoothPermission(context)) {
        promise.reject("BLUETOOTH_PERMISSION_REQUIRED", "يجب السماح بالاتصال بأجهزة Bluetooth", null)
        return@AsyncFunction
      }

      val adapter = BluetoothAdapter.getDefaultAdapter()
      if (adapter == null) {
        promise.resolve(emptyList<Map<String, Any>>())
        return@AsyncFunction
      }
      resolvePairedDevices(context, adapter, promise)
    }

    AsyncFunction("startMonitoring") { address: String, name: String, delaySeconds: Int, tone: String, customToneUri: String?, flashEnabled: Boolean, promise: Promise ->
      val context = appContext.reactContext
      if (context == null) {
        promise.reject("CONTEXT_UNAVAILABLE", "لم يتهيأ سياق Android بعد", null)
        return@AsyncFunction
      }
      if (!hasBluetoothPermission(context)) {
        promise.reject("BLUETOOTH_PERMISSION_REQUIRED", "يجب السماح بالاتصال بأجهزة Bluetooth", null)
        return@AsyncFunction
      }

      val intent = Intent(context, BluetoothGuardService::class.java).apply {
        action = BluetoothGuardService.ACTION_START
        putExtra(BluetoothGuardService.EXTRA_ADDRESS, address)
        putExtra(BluetoothGuardService.EXTRA_NAME, name)
        putExtra(BluetoothGuardService.EXTRA_DELAY_SECONDS, delaySeconds)
        putExtra(BluetoothGuardService.EXTRA_TONE, tone)
        putExtra(BluetoothGuardService.EXTRA_CUSTOM_TONE_URI, customToneUri)
        putExtra(BluetoothGuardService.EXTRA_FLASH_ENABLED, flashEnabled)
      }
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
      promise.resolve(null)
    }

    AsyncFunction("stopMonitoring") { promise: Promise ->
      val context = appContext.reactContext
      if (context != null) context.stopService(Intent(context, BluetoothGuardService::class.java))
      promise.resolve(null)
    }

    AsyncFunction("getMonitorState") { promise: Promise ->
      val context = appContext.reactContext
      promise.resolve(context?.getSharedPreferences(BluetoothGuardService.PREFERENCES, Context.MODE_PRIVATE)?.getString(BluetoothGuardService.KEY_STATE, "idle") ?: "idle")
    }

    AsyncFunction("playPreviewTone") { tone: String, customToneUri: String?, flashEnabled: Boolean, promise: Promise ->
      val context = appContext.reactContext
      if (context == null) {
        promise.reject("CONTEXT_UNAVAILABLE", "لم يتهيأ سياق Android بعد", null)
        return@AsyncFunction
      }
      BluetoothGuardService.playPreviewTone(context, tone, customToneUri, flashEnabled)
      promise.resolve(null)
    }

    AsyncFunction("stopPreviewTone") { promise: Promise ->
      BluetoothGuardService.stopPreviewTone()
      promise.resolve(null)
    }

    AsyncFunction("playTapSound") { promise: Promise ->
      BluetoothGuardService.playTapSound()
      promise.resolve(null)
    }

    AsyncFunction("importCustomTone") { sourceUri: String, promise: Promise ->
      val context = appContext.reactContext
      if (context == null) {
        promise.reject("CONTEXT_UNAVAILABLE", "لم يتهيأ سياق Android بعد", null)
        return@AsyncFunction
      }
      try {
        val source = Uri.parse(sourceUri)
        val input = if (source.scheme == "file") {
          FileInputStream(requireNotNull(source.path))
        } else {
          requireNotNull(context.contentResolver.openInputStream(source))
        }
        val directory = File(context.filesDir, "jafer-guard").apply { mkdirs() }
        val destination = File(directory, "custom-alarm-tone")
        input.use { sourceStream ->
          FileOutputStream(destination).use { destinationStream -> sourceStream.copyTo(destinationStream) }
        }
        promise.resolve(Uri.fromFile(destination).toString())
      } catch (error: Exception) {
        promise.reject("CUSTOM_TONE_IMPORT_FAILED", "تعذر حفظ ملف النغمة", error)
      }
    }
  }

  private fun hasBluetoothPermission(context: Context): Boolean {
    return Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
      context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
  }

  private fun resolvePairedDevices(context: Context, adapter: BluetoothAdapter, promise: Promise) {
    val connectedAddresses = mutableSetOf<String>()
    val profileIds = listOf(BluetoothProfile.A2DP, BluetoothProfile.HEADSET)
    var pendingProfiles = profileIds.size

    fun resolveWhenReady() {
      pendingProfiles -= 1
      if (pendingProfiles > 0) return
      val devices = adapter.bondedDevices.map { device ->
        mapOf(
          "id" to device.address,
          "name" to (device.name ?: "سماعة Bluetooth"),
          "connected" to connectedAddresses.contains(device.address),
        )
      }
      promise.resolve(devices)
    }

    profileIds.forEach { requestedProfile ->
      val requested = adapter.getProfileProxy(context, object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
          connectedAddresses.addAll(proxy.connectedDevices.map { it.address })
          adapter.closeProfileProxy(profile, proxy)
          resolveWhenReady()
        }

        override fun onServiceDisconnected(profile: Int) = Unit
      }, requestedProfile)
      if (!requested) resolveWhenReady()
    }
  }
}
