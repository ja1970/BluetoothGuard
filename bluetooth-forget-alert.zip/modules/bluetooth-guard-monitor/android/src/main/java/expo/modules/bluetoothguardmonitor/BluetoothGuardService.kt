package expo.modules.bluetoothguardmonitor

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothProfile
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.Ringtone
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat

class BluetoothGuardService : Service() {
  private val handler = Handler(Looper.getMainLooper())
  private var monitoredAddress: String? = null
  private var monitoredName: String = "سماعة Bluetooth"
  private var delayMillis: Long = 3000L
  private var disconnected = false
  private var selectedTone: String = "alarm"
  private var customToneUri: String? = null
  private var flashEnabled = false
  private var torchOn = false
  private var activeRingtone: Ringtone? = null
  private var activeCustomPlayer: MediaPlayer? = null

  private val ringtoneRepeatRunnable = object : Runnable {
    override fun run() {
      if (!disconnected) return
      if (activeRingtone?.isPlaying != true) activeRingtone?.play()
      handler.postDelayed(this, RINGTONE_REPEAT_CHECK_MILLIS)
    }
  }

  private val flashRunnable = object : Runnable {
    override fun run() {
      if (!disconnected || !flashEnabled) return
      setTorch(!torchOn)
      handler.postDelayed(this, FLASH_INTERVAL_MILLIS)
    }
  }

  private val alarmRunnable = Runnable {
    if (disconnected) {
      setState("alerting")
      playAlarm()
      updateNotification("انقطعت السماعة — التنبيه يعمل")
    }
  }

  private val bluetoothReceiver = object : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
      val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE) ?: return
      if (device.address != monitoredAddress) return

      when (intent.action) {
        BluetoothDevice.ACTION_ACL_DISCONNECTED -> handleDisconnected()
        BluetoothDevice.ACTION_ACL_CONNECTED -> handleConnected()
        BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED,
        BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED -> {
          when (intent.getIntExtra(BluetoothProfile.EXTRA_STATE, BluetoothProfile.STATE_DISCONNECTED)) {
            BluetoothProfile.STATE_DISCONNECTED -> handleDisconnected()
            BluetoothProfile.STATE_CONNECTED -> handleConnected()
          }
        }
      }
    }
  }

  override fun onCreate() {
    super.onCreate()
    createNotificationChannel()
    val filter = IntentFilter().apply {
      addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
      addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
      addAction(BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED)
      addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED)
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      registerReceiver(bluetoothReceiver, filter, RECEIVER_NOT_EXPORTED)
    } else {
      registerReceiver(bluetoothReceiver, filter)
    }
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (intent?.action == ACTION_STOP) {
      stopSelf()
      return START_NOT_STICKY
    }

    monitoredAddress = intent?.getStringExtra(EXTRA_ADDRESS)
    monitoredName = intent?.getStringExtra(EXTRA_NAME) ?: monitoredName
    delayMillis = (intent?.getIntExtra(EXTRA_DELAY_SECONDS, 3) ?: 3).toLong() * 1000
    selectedTone = intent?.getStringExtra(EXTRA_TONE) ?: selectedTone
    customToneUri = intent?.getStringExtra(EXTRA_CUSTOM_TONE_URI)
    flashEnabled = intent?.getBooleanExtra(EXTRA_FLASH_ENABLED, false) ?: false
    setState("armed")
    startForeground(NOTIFICATION_ID, buildNotification("السماعة متصلة والحماية تعمل"))
    return START_STICKY
  }

  override fun onDestroy() {
    handler.removeCallbacksAndMessages(null)
    stopAlarm()
    unregisterReceiver(bluetoothReceiver)
    setState("idle")
    super.onDestroy()
  }

  override fun onBind(intent: Intent?): IBinder? = null

  private fun handleDisconnected() {
    disconnected = true
    setState("grace")
    updateNotification("فُصلت السماعة — نتحقق الآن")
    handler.removeCallbacks(alarmRunnable)
    handler.postDelayed(alarmRunnable, delayMillis)
  }

  private fun handleConnected() {
    disconnected = false
    handler.removeCallbacks(alarmRunnable)
    stopAlarm()
    setState("armed")
    updateNotification("السماعة متصلة والحماية تعمل")
  }

  private fun playAlarm() {
    handler.removeCallbacks(ringtoneRepeatRunnable)
    activeRingtone?.stop()
    activeRingtone = null
    activeCustomPlayer?.release()
    activeCustomPlayer = null
    if (selectedTone == "custom" && customToneUri != null) {
      activeCustomPlayer = createCustomTonePlayer(this, customToneUri!!)?.also { it.start() }
    }
    if (activeCustomPlayer == null) {
      activeRingtone = systemRingtone(this, selectedTone).also { ringtone ->
        ringtone.audioAttributes = alarmAttributes()
        ringtone.play()
      }
      handler.postDelayed(ringtoneRepeatRunnable, RINGTONE_REPEAT_CHECK_MILLIS)
    }
    if (flashEnabled) {
      handler.removeCallbacks(flashRunnable)
      flashRunnable.run()
    }
    val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 280, 130, 280), -1))
    } else {
      @Suppress("DEPRECATION") vibrator.vibrate(longArrayOf(0, 280, 130, 280), -1)
    }
  }

  private fun stopAlarm() {
    handler.removeCallbacks(ringtoneRepeatRunnable)
    handler.removeCallbacks(flashRunnable)
    setTorch(false)
    activeRingtone?.stop()
    activeRingtone = null
    activeCustomPlayer?.stop()
    activeCustomPlayer?.release()
    activeCustomPlayer = null
    val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
    vibrator.cancel()
  }

  private fun setState(state: String) {
    getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit().putString(KEY_STATE, state).apply()
  }

  private fun updateNotification(content: String) {
    val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
    manager.notify(NOTIFICATION_ID, buildNotification(content))
  }

  private fun setTorch(enabled: Boolean) {
    try {
      val manager = getSystemService(CAMERA_SERVICE) as CameraManager
      val cameraId = manager.cameraIdList.firstOrNull { id ->
        manager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
      } ?: return
      manager.setTorchMode(cameraId, enabled)
      torchOn = enabled
    } catch (_: Exception) {
      torchOn = false
    }
  }

  private fun buildNotification(content: String) = NotificationCompat.Builder(this, CHANNEL_ID)
    .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
    .setContentTitle("Jafer Guard")
    .setContentText(content)
    .setOngoing(true)
    .setOnlyAlertOnce(true)
    .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف الحماية", stopIntent())
    .build()

  private fun stopIntent(): PendingIntent {
    val intent = Intent(this, BluetoothGuardService::class.java).apply { action = ACTION_STOP }
    return PendingIntent.getService(this, 21, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(CHANNEL_ID, "حماية Bluetooth", NotificationManager.IMPORTANCE_LOW)
      channel.description = "يعرض حالة مراقبة السماعة في Bluetooth Guard"
      (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
    }
  }

  companion object {
    const val ACTION_START = "expo.modules.bluetoothguardmonitor.START"
    const val ACTION_STOP = "expo.modules.bluetoothguardmonitor.STOP"
    const val EXTRA_ADDRESS = "address"
    const val EXTRA_NAME = "name"
    const val EXTRA_DELAY_SECONDS = "delay_seconds"
    const val EXTRA_TONE = "tone"
    const val EXTRA_CUSTOM_TONE_URI = "custom_tone_uri"
    const val EXTRA_FLASH_ENABLED = "flash_enabled"
    const val PREFERENCES = "bluetooth_guard_monitor"
    const val KEY_STATE = "state"
    private const val CHANNEL_ID = "bluetooth_guard_monitor"
    private const val NOTIFICATION_ID = 9011
    private const val RINGTONE_REPEAT_CHECK_MILLIS = 800L
    private const val FLASH_INTERVAL_MILLIS = 420L

    fun isConnected(context: Context, address: String): Boolean {
      val adapter = BluetoothAdapter.getDefaultAdapter() ?: return false
      return adapter.bondedDevices.any { it.address == address }
    }

    private var previewRingtone: Ringtone? = null
    private var previewCustomPlayer: MediaPlayer? = null

    fun playPreviewTone(context: Context, toneName: String, customToneUri: String?, flashEnabled: Boolean) {
      stopPreviewTone()
      if (toneName == "custom" && customToneUri != null) {
        previewCustomPlayer = createCustomTonePlayer(context, customToneUri)?.also { it.start() }
      }
      if (previewCustomPlayer == null) {
        previewRingtone = systemRingtone(context, toneName).also {
          it.audioAttributes = alarmAttributes()
          it.play()
        }
      }
    }

    fun stopPreviewTone() {
      previewRingtone?.stop()
      previewRingtone = null
      previewCustomPlayer?.stop()
      previewCustomPlayer?.release()
      previewCustomPlayer = null
    }

    fun playTapSound() {
      val tone = ToneGenerator(AudioManager.STREAM_SYSTEM, 58)
      tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 55)
      Handler(Looper.getMainLooper()).postDelayed({ tone.release() }, 85)
    }

    private fun systemRingtone(context: Context, toneName: String): Ringtone {
      val type = when (toneName) {
        "notification" -> RingtoneManager.TYPE_NOTIFICATION
        "ringtone" -> RingtoneManager.TYPE_RINGTONE
        else -> RingtoneManager.TYPE_ALARM
      }
      val uri = RingtoneManager.getActualDefaultRingtoneUri(context, type)
        ?: RingtoneManager.getDefaultUri(type)
      return requireNotNull(RingtoneManager.getRingtone(context, uri))
    }

    private fun alarmAttributes() = AudioAttributes.Builder()
      .setUsage(AudioAttributes.USAGE_ALARM)
      .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
      .build()

    private fun createCustomTonePlayer(context: Context, uriString: String): MediaPlayer? {
      return try {
        MediaPlayer().apply {
          setAudioAttributes(alarmAttributes())
          setDataSource(context, Uri.parse(uriString))
          isLooping = true
          setVolume(1f, 1f)
          prepare()
        }
      } catch (_: Exception) {
        null
      }
    }
  }
}
