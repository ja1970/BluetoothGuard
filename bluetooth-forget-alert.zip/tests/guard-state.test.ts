import { describe, expect, it } from "vitest";

import { findSingleConnectedDevice, reduceGuardState } from "../lib/guard-state";
import { nextOnboardingStep } from "../lib/onboarding";

describe("guard monitoring state", () => {
  it("moves from armed to a grace period, then alerting after a sustained disconnect", () => {
    const grace = reduceGuardState("armed", { type: "DISCONNECTED" });
    expect(grace).toBe("grace");
    expect(reduceGuardState(grace, { type: "ALERT" })).toBe("alerting");
  });

  it("cancels a pending alert when the headset reconnects during the grace period", () => {
    expect(reduceGuardState("grace", { type: "RECONNECTED" })).toBe("armed");
  });

  it("always stops monitoring when the user disables protection", () => {
    expect(reduceGuardState("alerting", { type: "STOP" })).toBe("idle");
  });

  it("selects a connected headset only when exactly one device is connected", () => {
    const oneConnected = [
      { id: "one", connected: false },
      { id: "two", connected: true },
    ];
    expect(findSingleConnectedDevice(oneConnected)?.id).toBe("two");
    expect(findSingleConnectedDevice([{ id: "one", connected: true }, { id: "two", connected: true }])).toBeNull();
  });

  it("advances onboarding without exceeding the final step", () => {
    expect(nextOnboardingStep(0)).toBe(1);
    expect(nextOnboardingStep(1)).toBe(2);
    expect(nextOnboardingStep(2)).toBe(3);
    expect(nextOnboardingStep(3)).toBe(3);
  });
});
