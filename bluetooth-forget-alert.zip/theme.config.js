/** @type {const} */
const themeColors = {
  primary: { light: '#1463FF', dark: '#78A4FF' },
  background: { light: '#EDF2F8', dark: '#0B1220' },
  surface: { light: '#FFFFFF', dark: '#17233B' },
  foreground: { light: '#0B1220', dark: '#F7F9FC' },
  muted: { light: '#647084', dark: '#A8B2C3' },
  border: { light: '#E4E9F2', dark: '#2E3B54' },
  success: { light: '#1FA971', dark: '#54D9A5' },
  warning: { light: '#E07A19', dark: '#FFB05C' },
  error: { light: '#D93C3C', dark: '#FF858B' },
};

module.exports = { themeColors };
