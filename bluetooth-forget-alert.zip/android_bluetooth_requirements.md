# متطلبات Android لمراقبة فصل سماعة Bluetooth

تشير وثائق Android الرسمية إلى أن التطبيق الذي يتعامل مع أجهزة Bluetooth المقترنة على Android 12 وما بعده يحتاج تصريح `BLUETOOTH_CONNECT`، بينما يحتاج `BLUETOOTH_SCAN` فقط عندما يبحث التطبيق عن أجهزة. بما أن النسخة الأولى ستعتمد على سماعة مقترنة يختارها المستخدم، فإن التصريح الأساسي هو `BLUETOOTH_CONNECT` مع طلبه وقت التشغيل. [1]

ولأن مراقبة الانفصال ينبغي أن تستمر بوضوح بعد مغادرة المستخدم للشاشة، فإن التنفيذ الإنتاجي يحتاج خدمة أمامية ظاهرة للمستخدم مع إشعار مستمر، ويصنّف استخدامها تحت نوع `connectedDevice` في Android 14 وما بعده. يقتصر النموذج الأولي على واجهة ومحاكاة قابلة للاختبار داخل Expo، ثم يُستبدل بمكوّن Android أصلي أو مكتبة متوافقة مع Expo development build لتلقي بث انفصال Bluetooth من النظام. [2]

يؤكد Expo أن إمكانات Android التي لا يوفّرها Expo SDK يمكن إضافتها من خلال وحدة أصلية محلية مكتوبة بـKotlin، وتُستدعى من TypeScript عبر Expo Modules API. لذلك سيضم المشروع وحدة Android محلية باسم `BluetoothGuardMonitor` لتلقي بث الاتصال والانفصال، مع طبقة TypeScript آمنة تسمح للواجهة بالعمل في المعاينة دون الادعاء بأن مراقبة Bluetooth الفعلية متاحة فيها. [3]

لا يصلح تقدير مسافة ثابتة مثل 3 أمتار بالاعتماد على قوة الإشارة RSSI كشرط دقيق لسماعة سوق عادية. فالمصادر التقنية تصف RSSI بأنه ذو دقة محدودة وعدم يقين مرتفع لتأثره بالقناة اللاسلكية والعوائق، كما أن واجهة Android لجهاز Bluetooth تركز على الاسم والعنوان وحالة الربط ولا توفر مسافة معيارية مستمرة لسماعة صوتية متصلة. لذلك يجب أن يكون انقطاع الاتصال هو شرط الإنذار الموثوق، مع إمكان تقديم «إنذار قرب تقريبي» تجريبي فقط إذا كانت السماعة تدعم BLE ويمكن قياس RSSI بصورة متكررة. [4] [5]

## المراجع

[1] [Android Developers — Bluetooth permissions](https://developer.android.com/develop/connectivity/bluetooth/bt-permissions).  
[2] [Android Developers — Foreground service types are required](https://developer.android.com/about/versions/14/changes/fgs-types-required).
[3] [Expo Documentation — Tutorial: Create a native module](https://docs.expo.dev/modules/native-module-tutorial/).
[4] [Rohde & Schwarz — Bluetooth positioning & distance measurements](https://www.rohde-schwarz.com/us/solutions/wireless-communications-testing/wireless-standards/bluetooth/bluetooth-direction-finding/bluetooth-direction-finding_251246.html).  
[5] [Android Developers — BluetoothDevice API reference](https://developer.android.com/reference/android/bluetooth/BluetoothDevice).
