import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

export type AppLanguage = "ar" | "en";
type Dictionary = Record<string, string>;

const copy: Record<AppLanguage, Dictionary> = {
  ar: {
    appSubtitle: "حارس نسيان الهاتف",
    protection: "الحماية",
    settings: "الإعدادات",
    language: "اللغة",
    arabic: "العربية",
    english: "English",
    statusIdle: "الحماية غير مفعّلة",
    statusIdleDetail: "شغّل الحماية لحماية هاتفك من النسيان.",
    statusArmed: "هاتفك محمي",
    statusArmedDetail: "Jafer Guard يراقب اتصال Bluetooth.",
    protectionOn: "الحماية مفعّلة",
    protectionOff: "الحماية متوقفة",
    statusGrace: "نتحقق من الانفصال",
    statusGraceDetail: "ننتظر مهلة الحماية قبل إطلاق الإنذار.",
    statusAlert: "قد تكون ابتعدت عن هاتفك",
    statusAlertDetail: "انقطعت السماعة وبدأ إنذار الهاتف. أوقفه بعد التحقق.",
    alarmActive: "الإنذار يعمل الآن",
    alarmActiveDetail: "تومض الشاشة باللون الأحمر لتلفت انتباهك إلى الانفصال.",
    silenceAlarm: "إسكات الإنذار",
    monitoredDevice: "الجهاز المحمي",
    noDevice: "لم تُختر سماعة بعد",
    connected: "متصلة",
    waiting: "بانتظار الحماية",
    changeDevice: "تغيير السماعة",
    chooseConnected: "اختيار السماعة المتصلة",
    enableProtection: "تشغيل الحماية",
    disableProtection: "إيقاف الحماية",
    delaySummary: "مدة الانتظار قبل الإنذار: {seconds} ثانية",
    protectionTitle: "حماية الهاتف",
    lastConnectedNow: "آخر اتصال: الآن",
    disconnectedNow: "انقطع الاتصال الآن",
    onDisconnect: "عند انقطاع الاتصال",
    onDisconnectDetail: "جرس مستمر، وميض أحمر، واهتزاز الهاتف",
    disconnectAlarm: "تشغيل الإنذار",
    disconnectVibration: "اهتزاز الهاتف",
    disconnectVisual: "تنبيه مرئي",
    disconnectAfter: "بعد {seconds} ثوانٍ",
    chooseTone: "اختيار نغمة الإنذار",
    testAlarm: "تجربة الإنذار",
    testAlarmNow: "تجربة الإنذار الآن",
    testAlarmDetail: "تشغيل تنبيه من الهاتف الآن",
    previewNotice: "المعاينة لا تصل إلى سماعة هاتفك الحقيقية. استخدم المحاكاة لاختبار مهلة الانفصال والوميض، أما نغمة الهاتف ومراقبة السماعة فتعملان في نسخة Android المبنية.",
    simulateDisconnect: "محاكاة فصل السماعة",
    simulateReconnect: "محاكاة إعادة الاتصال",
    chooseHeadset: "اختر سماعة Bluetooth",
    pairedHeadsets: "تظهر هنا السماعات المقترنة بالهاتف.",
    previewDevice: "معاينة الواجهة",
    paired: "مقترنة",
    noPairedDevices: "لا توجد سماعات مقترنة حاليًا.",
    cancel: "إلغاء",
    permissionInfo: "كيف تعمل الحماية؟",
    permissionDetail: "يحتاج Jafer Guard إلى Bluetooth لرصد السماعة، وإلى الإشعارات والعمل في الخلفية كي يستمر التنبيه عندما تكون الشاشة مقفلة. يطلب التطبيق الصلاحيات عند تشغيل الحماية.",
    delayTitle: "مدة تأخير الإنذار",
    delayDetail: "لا يبدأ التنبيه مباشرةً بعد الفصل لتجنب الإنذارات العابرة.",
    toneTitle: "نغمة الإنذار",
    toneDetail: "اختر نغمة من نغمات هاتفك النظامية للتنبيه عند فصل السماعة.",
    toneAlarm: "جرس المنبّه",
    toneNotification: "نغمة الإشعار",
    toneRingtone: "نغمة الرنين",
    toneCustom: "نغمة من الجهاز",
    volumeTitle: "مستوى صوت التنبيه",
    volumeDetail: "تعمل النغمة المتكررة على مسار المنبّه؛ ارفع صوت المنبّه من إعدادات هاتفك إذا احتجت صوتًا أعلى.",
    vibrationTitle: "الاهتزاز عند الانفصال",
    vibrationDetail: "أضف اهتزازًا قصيرًا إلى صوت الإنذار.",
    testCurrentAlarm: "تجربة الإنذار الحالي",
    alarmSettingsTitle: "إعدادات نغمة الإنذار",
    alarmSettingsDetail: "اختر صوت الإنذار الذي سيعمل عند فقدان اتصال Bluetooth.",
    currentTone: "النغمة الحالية",
    preview: "معاينة",
    availableTones: "النغمات المتاحة",
    toneAlarmDescription: "النغمة الافتراضية للمنبّه",
    toneNotificationDescription: "استخدم صوت إشعارات الهاتف",
    toneRingtoneDescription: "استخدم نغمة رنين الهاتف",
    toneCustomDescription: "اختر ملفًا صوتيًا من جهازك",
    tonePickerErrorTitle: "تعذر اختيار النغمة",
    tonePickerErrorDetail: "اختر ملفًا صوتيًا صالحًا ثم حاول مرة أخرى.",
    chooseFile: "اختيار ملف",
    alarmVolume: "مستوى صوت الإنذار",
    alarmVolumeDetail: "اختر المستوى، ثم ارفع مستوى المنبّه من إعدادات الهاتف إذا احتجت صوتًا أعلى.",
    low: "منخفض",
    medium: "متوسط",
    high: "مرتفع",
    flashTitle: "الفلاش عند الانفصال",
    flashDetail: "يومض فلاش الهاتف مع الإنذار بعد منح إذن الكاميرا.",
    onboardingSkip: "تخطي الآن",
    onboardingStepCount: "الخطوة {current} من {total}",
    onboardingWelcomeTitle: "حافظ على هاتفك قريبًا",
    onboardingWelcomeDetail: "سيتابع Jafer Guard اتصال سماعة Bluetooth وينبّه هاتفك عند انقطاعه.",
    onboardingStepDeviceTitle: "اختر سماعة Bluetooth",
    onboardingStepDeviceDetail: "سنراقب هذه السماعة ونتأكد من تنبيه هاتفك عندما ينقطع اتصالها.",
    onboardingStepAlertTitle: "حدد طريقة التنبيه",
    onboardingStepAlertDetail: "اختر الجرس وحدد التأخير والاهتزاز حتى يناسبك التنبيه تمامًا.",
    onboardingStepProtectTitle: "فعّل الحماية",
    onboardingStepProtectDetail: "بعد الإعداد، يبدأ Jafer Guard في حماية هاتفك من النسيان.",
    onboardingNext: "التالي",
    onboardingFinish: "ابدأ الحماية",
    replayIntroduction: "إعادة تشغيل المقدمة الترحيبية",
  },
  en: {
    appSubtitle: "Phone Forget Guard",
    protection: "Protection",
    settings: "Settings",
    language: "Language",
    arabic: "العربية",
    english: "English",
    statusIdle: "Protection is not active",
    statusIdleDetail: "Turn on protection to help keep your phone from being left behind.",
    statusArmed: "Your phone is protected",
    statusArmedDetail: "Jafer Guard is monitoring the Bluetooth connection.",
    protectionOn: "PROTECTION ON",
    protectionOff: "PROTECTION OFF",
    statusGrace: "Checking the disconnection",
    statusGraceDetail: "Waiting for the safety delay before sounding the alarm.",
    statusAlert: "You may have left your phone behind",
    statusAlertDetail: "The headset disconnected and the phone alarm has started.",
    alarmActive: "Alarm is active",
    alarmActiveDetail: "The screen flashes red to draw attention to the disconnection.",
    silenceAlarm: "Silence alarm",
    monitoredDevice: "PROTECTED DEVICE",
    noDevice: "No headset selected",
    connected: "Connected",
    waiting: "Waiting",
    changeDevice: "Change headset",
    chooseConnected: "Choose connected headset",
    enableProtection: "Enable protection",
    disableProtection: "Stop protection",
    delaySummary: "Alarm delay: {seconds} seconds",
    protectionTitle: "Phone protection",
    lastConnectedNow: "Last connected: now",
    disconnectedNow: "Connection lost now",
    onDisconnect: "On disconnection",
    onDisconnectDetail: "Continuous bell, red flash, and phone vibration",
    disconnectAlarm: "Play alarm",
    disconnectVibration: "Vibrate phone",
    disconnectVisual: "Visual alert",
    disconnectAfter: "After {seconds} seconds",
    chooseTone: "Choose alarm tone",
    testAlarm: "Test alarm",
    testAlarmNow: "Test the alarm now",
    testAlarmDetail: "Play a phone alert now",
    previewNotice: "Preview cannot access your real headset. Use simulation to test the delay and red flash; phone audio and Bluetooth monitoring work in a built Android app.",
    simulateDisconnect: "Simulate disconnect",
    simulateReconnect: "Simulate reconnect",
    chooseHeadset: "Choose a Bluetooth headset",
    pairedHeadsets: "Paired headsets appear here.",
    previewDevice: "UI preview",
    paired: "Paired",
    noPairedDevices: "No paired headsets found.",
    cancel: "Cancel",
    permissionInfo: "How does protection work?",
    permissionDetail: "Jafer Guard needs Bluetooth to watch the headset, plus notifications and background access to alert you while the screen is locked. Permissions are requested when protection starts.",
    delayTitle: "Alarm delay",
    delayDetail: "The alarm does not start immediately, which helps avoid temporary-disconnect alerts.",
    toneTitle: "Alarm tone",
    toneDetail: "Choose one of your phone's system tones for a headset disconnection.",
    toneAlarm: "Alarm bell",
    toneNotification: "Notification tone",
    toneRingtone: "Phone ringtone",
    toneCustom: "Tone from device",
    volumeTitle: "Alarm volume",
    volumeDetail: "The repeated tone uses the alarm audio path. Raise your phone's alarm volume if you need a louder alert.",
    vibrationTitle: "Vibrate on disconnect",
    vibrationDetail: "Add a short vibration to the alarm sound.",
    testCurrentAlarm: "Test current alarm",
    alarmSettingsTitle: "Alarm tone settings",
    alarmSettingsDetail: "Choose the sound that plays when the Bluetooth connection is lost.",
    currentTone: "CURRENT TONE",
    preview: "Preview",
    availableTones: "AVAILABLE TONES",
    toneAlarmDescription: "Use your phone's default alarm bell",
    toneNotificationDescription: "Use your phone's notification sound",
    toneRingtoneDescription: "Use your phone's ringtone",
    toneCustomDescription: "Choose an audio file from your device",
    tonePickerErrorTitle: "Unable to select tone",
    tonePickerErrorDetail: "Choose a valid audio file, then try again.",
    chooseFile: "Choose file",
    alarmVolume: "Alarm volume",
    alarmVolumeDetail: "Choose a level, then raise your phone's alarm volume for a louder alert.",
    low: "Low",
    medium: "Medium",
    high: "High",
    flashTitle: "Flash on disconnect",
    flashDetail: "Your phone flash blinks with the alarm after camera permission is granted.",
    onboardingSkip: "Skip for now",
    onboardingStepCount: "Step {current} of {total}",
    onboardingWelcomeTitle: "Keep your phone close",
    onboardingWelcomeDetail: "Jafer Guard watches your Bluetooth headset and alerts your phone when the connection is lost.",
    onboardingStepDeviceTitle: "Choose a Bluetooth headset",
    onboardingStepDeviceDetail: "We will monitor this headset and alert your phone when its connection is lost.",
    onboardingStepAlertTitle: "Choose how to be alerted",
    onboardingStepAlertDetail: "Choose the bell, delay, and vibration that work best for you.",
    onboardingStepProtectTitle: "Enable protection",
    onboardingStepProtectDetail: "After setup, Jafer Guard starts protecting your phone from being left behind.",
    onboardingNext: "Next",
    onboardingFinish: "Start protection",
    replayIntroduction: "Replay introduction",
  },
};

type LanguageContextValue = {
  language: AppLanguage;
  setLanguage: (language: AppLanguage) => Promise<void>;
  t: (key: string, values?: Record<string, string | number>) => string;
};

const LanguageContext = createContext<LanguageContextValue | null>(null);
const LANGUAGE_KEY = "jafer-guard.language";

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<AppLanguage>("ar");

  useEffect(() => {
    AsyncStorage.getItem(LANGUAGE_KEY).then((saved) => {
      if (saved === "ar" || saved === "en") setLanguageState(saved);
    }).catch(() => undefined);
  }, []);

  const setLanguage = useCallback(async (nextLanguage: AppLanguage) => {
    setLanguageState(nextLanguage);
    await AsyncStorage.setItem(LANGUAGE_KEY, nextLanguage);
  }, []);

  const t = useCallback((key: string, values?: Record<string, string | number>) => {
    let value = copy[language][key] ?? copy.ar[key] ?? key;
    Object.entries(values ?? {}).forEach(([name, replacement]) => {
      value = value.replace(`{${name}}`, String(replacement));
    });
    return value;
  }, [language]);

  const value = useMemo(() => ({ language, setLanguage, t }), [language, setLanguage, t]);
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const value = useContext(LanguageContext);
  if (!value) throw new Error("useLanguage must be used within LanguageProvider");
  return value;
}
