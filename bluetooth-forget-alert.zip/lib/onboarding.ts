export const ONBOARDING_KEY = "jafer-guard.onboarding-complete";
export const ONBOARDING_STEP_COUNT = 4;

export function nextOnboardingStep(step: number): number {
  return Math.min(step + 1, ONBOARDING_STEP_COUNT - 1);
}
