import type { MonitorState } from "@/lib/bluetooth-guard";

export type GuardAction =
  | { type: "ARM" }
  | { type: "DISCONNECTED" }
  | { type: "RECONNECTED" }
  | { type: "ALERT" }
  | { type: "STOP" };

export function reduceGuardState(state: MonitorState, action: GuardAction): MonitorState {
  switch (action.type) {
    case "ARM":
      return "armed";
    case "DISCONNECTED":
      return state === "armed" ? "grace" : state;
    case "RECONNECTED":
      return state === "idle" ? "idle" : "armed";
    case "ALERT":
      return state === "grace" ? "alerting" : state;
    case "STOP":
      return "idle";
    default:
      return state;
  }
}

export function findSingleConnectedDevice<T extends { connected: boolean }>(devices: readonly T[]): T | null {
  const connectedDevices = devices.filter((device) => device.connected);
  return connectedDevices.length === 1 ? connectedDevices[0] : null;
}
