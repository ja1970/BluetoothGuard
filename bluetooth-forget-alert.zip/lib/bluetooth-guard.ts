import AsyncStorage from "@react-native-async-storage/async-storage";
import * as DocumentPicker from "expo-document-picker";
import { NativeModules, PermissionsAndroid, Platform, Vibration } from "react-native";

export { findSingleConnectedDevice } from "@/lib/guard-state";

export type AlarmTone = "alarm" | "notification" | "ringtone" | "custom";

export type GuardSettings = {
  delaySeconds: 3 | 5 | 10 | 20 | 30;
  volume: 40 | 70 | 100;
  vibrationEnabled: boolean;
  flashEnabled: boolean;
  tone: AlarmTone;
  customToneUri: string | null;
  customToneName: string | null;
};

export type BluetoothDeviceSummary = {
  id: string;
  name: string;
  connected: boolean;
  isPreview?: boolean;
};

export type MonitorState = "idle" | "armed" | "grace" | "alerting";

type BluetoothGuardNativeModule = {
  getPairedDevices: () => Promise<BluetoothDeviceSummary[]>;
  startMonitoring: (address: string, name: string, delaySeconds: number, tone: AlarmTone, customToneUri: string | null, flashEnabled: boolean) => Promise<void>;
  stopMonitoring: () => Promise<void>;
  getMonitorState: () => Promise<MonitorState>;
  playPreviewTone: (tone: AlarmTone, customToneUri: string | null, flashEnabled: boolean) => Promise<void>;
  stopPreviewTone: () => Promise<void>;
  playTapSound: () => Promise<void>;
  importCustomTone: (sourceUri: string) => Promise<string>;
};

const nativeMonitor = NativeModules.BluetoothGuardMonitor as BluetoothGuardNativeModule | undefined;

export const DEFAULT_SETTINGS: GuardSettings = {
  delaySeconds: 3,
  volume: 100,
  vibrationEnabled: true,
  flashEnabled: false,
  tone: "alarm",
  customToneUri: null,
  customToneName: null,
};

const SETTINGS_KEY = "bluetooth-guard.settings";
const DEVICE_KEY = "bluetooth-guard.device";

const PREVIEW_DEVICE: BluetoothDeviceSummary = {
  id: "preview-headset",
  name: "سماعة Bluetooth التجريبية",
  connected: true,
  isPreview: true,
};

type AudioContextConstructor = new () => AudioContext;
const webAudioGlobals = globalThis as unknown as {
  AudioContext?: AudioContextConstructor;
  webkitAudioContext?: AudioContextConstructor;
};
let webAudioContext: AudioContext | null = null;
let activeWebOscillators: OscillatorNode[] = [];
let webToneTimer: ReturnType<typeof setInterval> | null = null;
let activeWebCustomAudio: HTMLAudioElement | null = null;

export const monitorAvailable = Platform.OS === "android" && Boolean(nativeMonitor);

function getWebAudioContext(): AudioContext | null {
  if (Platform.OS !== "web") return null;
  const AudioContextClass = webAudioGlobals.AudioContext ?? webAudioGlobals.webkitAudioContext;
  if (!AudioContextClass) return null;
  webAudioContext ??= new AudioContextClass();
  return webAudioContext;
}

function stopWebTone() {
  if (webToneTimer) clearInterval(webToneTimer);
  webToneTimer = null;
  if (activeWebCustomAudio) {
    activeWebCustomAudio.pause();
    activeWebCustomAudio.currentTime = 0;
    activeWebCustomAudio = null;
  }
  activeWebOscillators.forEach((oscillator) => {
    try {
      oscillator.stop();
    } catch {
      // The oscillator may already have reached its scheduled stop time.
    }
  });
  activeWebOscillators = [];
}

export async function prepareAlarmAudio() {
  const context = getWebAudioContext();
  if (context?.state === "suspended") await context.resume();
}

function playWebTapSound() {
  const context = getWebAudioContext();
  if (!context) return;
  const oscillator = context.createOscillator();
  const gain = context.createGain();
  const now = context.currentTime;
  oscillator.type = "sine";
  oscillator.frequency.setValueAtTime(720, now);
  oscillator.frequency.exponentialRampToValueAtTime(980, now + 0.045);
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.12, now + 0.008);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.065);
  oscillator.connect(gain);
  gain.connect(context.destination);
  oscillator.start(now);
  oscillator.stop(now + 0.07);
}

export async function playUiTapFeedback() {
  try {
    if (Platform.OS === "web") {
      await prepareAlarmAudio();
      playWebTapSound();
      return;
    }
    if (nativeMonitor && Platform.OS === "android") await nativeMonitor.playTapSound();
  } catch {
    // Interaction feedback is optional and must never prevent the requested action.
  }
}

function playWebBellCycle(tone: Exclude<AlarmTone, "custom">, volume: GuardSettings["volume"]) {
  const context = getWebAudioContext();
  if (!context) return;
  const patterns: Record<Exclude<AlarmTone, "custom">, Array<{ frequency: number; start: number; duration: number }>> = {
    alarm: [{ frequency: 880, start: 0, duration: 0.34 }, { frequency: 1046, start: 0.42, duration: 0.34 }, { frequency: 880, start: 0.84, duration: 0.54 }],
    notification: [{ frequency: 784, start: 0, duration: 0.24 }, { frequency: 988, start: 0.30, duration: 0.30 }, { frequency: 784, start: 0.68, duration: 0.42 }],
    ringtone: [{ frequency: 659, start: 0, duration: 0.28 }, { frequency: 659, start: 0.36, duration: 0.28 }, { frequency: 880, start: 0.74, duration: 0.54 }],
  };
  const now = context.currentTime;
  const gainValue = 0.55 + (volume / 100) * 0.35;
  activeWebOscillators = [];

  patterns[tone].forEach(({ frequency, start, duration }) => {
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    const startAt = now + start;
    const stopAt = startAt + duration;
    oscillator.type = "square";
    oscillator.frequency.setValueAtTime(frequency, startAt);
    gain.gain.setValueAtTime(0.0001, startAt);
    gain.gain.exponentialRampToValueAtTime(gainValue, startAt + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, stopAt);
    oscillator.connect(gain);
    gain.connect(context.destination);
    oscillator.start(startAt);
    oscillator.stop(stopAt + 0.02);
    activeWebOscillators.push(oscillator);
  });
}

function startWebBell(tone: Exclude<AlarmTone, "custom">, volume: GuardSettings["volume"]) {
  stopWebTone();
  playWebBellCycle(tone, volume);
  webToneTimer = setInterval(() => playWebBellCycle(tone, volume), 1650);
}

function startWebCustomTone(uri: string, volume: GuardSettings["volume"]) {
  stopWebTone();
  const audio = new Audio(uri);
  audio.loop = true;
  audio.volume = Math.min(1, 0.55 + (volume / 100) * 0.45);
  activeWebCustomAudio = audio;
  void audio.play().catch(() => undefined);
}

export async function requestBluetoothPermissions(flashEnabled = false) {
  if (Platform.OS !== "android") return true;
  if (Number(Platform.Version) < 31) return true;

  const permissions = [
    PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
    PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
    ...(Number(Platform.Version) >= 33 ? [PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS] : []),
    ...(flashEnabled ? [PermissionsAndroid.PERMISSIONS.CAMERA] : []),
  ];
  const result = await PermissionsAndroid.requestMultiple(permissions);
  return permissions.every((permission) => result[permission] === PermissionsAndroid.RESULTS.GRANTED);
}

export async function listPairedDevices(): Promise<BluetoothDeviceSummary[]> {
  if (!nativeMonitor) return [PREVIEW_DEVICE];
  const devices = await nativeMonitor.getPairedDevices();
  return devices.length ? devices : [];
}

export async function startMonitoring(device: BluetoothDeviceSummary, settings: GuardSettings): Promise<void> {
  if (nativeMonitor && !device.isPreview) {
    await nativeMonitor.startMonitoring(device.id, device.name, settings.delaySeconds, settings.tone, settings.customToneUri, settings.flashEnabled);
  }
}

export async function stopMonitoring(): Promise<void> {
  if (nativeMonitor) await nativeMonitor.stopMonitoring();
}

export async function loadSettings(): Promise<GuardSettings> {
  const stored = await AsyncStorage.getItem(SETTINGS_KEY);
  if (!stored) return DEFAULT_SETTINGS;

  const saved = JSON.parse(stored) as Partial<GuardSettings>;
  const tone = saved.tone === "alarm" || saved.tone === "notification" || saved.tone === "ringtone" || saved.tone === "custom"
    ? saved.tone
    : DEFAULT_SETTINGS.tone;
  return { ...DEFAULT_SETTINGS, ...saved, tone };
}

export async function saveSettings(settings: GuardSettings): Promise<void> {
  await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export async function loadSelectedDevice(): Promise<BluetoothDeviceSummary | null> {
  const stored = await AsyncStorage.getItem(DEVICE_KEY);
  return stored ? JSON.parse(stored) : null;
}

export async function saveSelectedDevice(device: BluetoothDeviceSummary): Promise<void> {
  await AsyncStorage.setItem(DEVICE_KEY, JSON.stringify(device));
}

export async function pickCustomTone(): Promise<{ uri: string; name: string } | null> {
  const result = await DocumentPicker.getDocumentAsync({ type: "audio/*", multiple: false, copyToCacheDirectory: true });
  if (result.canceled) return null;

  const asset = result.assets[0];
  const persistedUri = nativeMonitor && Platform.OS === "android"
    ? await nativeMonitor.importCustomTone(asset.uri)
    : asset.uri;
  return { uri: persistedUri, name: asset.name };
}

export async function playAlarmPreview(settings: GuardSettings) {
  if (Platform.OS === "web") {
    try {
      await prepareAlarmAudio();
      if (settings.tone === "custom" && settings.customToneUri) {
        startWebCustomTone(settings.customToneUri, settings.volume);
      } else {
        startWebBell(settings.tone === "custom" ? "alarm" : settings.tone, settings.volume);
      }
    } catch {
      // The visual alert remains available if browser audio is blocked.
    }
  }

  if (nativeMonitor && Platform.OS === "android") {
    try {
      await nativeMonitor.playPreviewTone(settings.tone, settings.customToneUri, settings.flashEnabled);
    } catch {
      // The visual alert and vibration remain available if system sound is unavailable.
    }
  }

  if (settings.vibrationEnabled && Platform.OS !== "web") {
    Vibration.vibrate(settings.tone === "notification" ? [0, 180, 90, 180, 90, 180] : [0, 320, 130, 320]);
  }
}

export async function stopAlarmPreview() {
  if (Platform.OS === "web") stopWebTone();
  if (nativeMonitor && Platform.OS === "android") {
    try {
      await nativeMonitor.stopPreviewTone();
    } catch {
      // The native player may already be stopped.
    }
  }
  Vibration.cancel();
}
