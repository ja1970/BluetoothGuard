import { MaterialIcons } from "@expo/vector-icons";
import { Stack, useRouter } from "expo-router";
import { useEffect, useState, type ReactNode } from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Switch, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { DEFAULT_SETTINGS, type AlarmTone, type GuardSettings, loadSettings, pickCustomTone, playAlarmPreview, playUiTapFeedback, saveSettings, stopAlarmPreview } from "@/lib/bluetooth-guard";
import { useLanguage } from "@/lib/language";

const TONES: Array<{ tone: AlarmTone; icon: keyof typeof MaterialIcons.glyphMap; color: string; detailKey: string }> = [
  { tone: "alarm", icon: "notifications-active", color: "#E07A19", detailKey: "toneAlarmDescription" },
  { tone: "notification", icon: "campaign", color: "#1463FF", detailKey: "toneNotificationDescription" },
  { tone: "ringtone", icon: "phone-in-talk", color: "#6E56CF", detailKey: "toneRingtoneDescription" },
  { tone: "custom", icon: "music-note", color: "#1FA971", detailKey: "toneCustomDescription" },
];

export default function AlarmSettingsScreen() {
  const router = useRouter();
  const { t } = useLanguage();
  const [settings, setSettings] = useState<GuardSettings>(DEFAULT_SETTINGS);

  useEffect(() => {
    loadSettings().then(setSettings).catch(() => undefined);
    return () => { void stopAlarmPreview(); };
  }, []);

  const update = (patch: Partial<GuardSettings>) => {
    const next = { ...settings, ...patch };
    setSettings(next);
    void saveSettings(next);
  };

  const chooseCustomTone = async () => {
    try {
      const file = await pickCustomTone();
      if (file) update({ tone: "custom", customToneUri: file.uri, customToneName: file.name });
    } catch {
      Alert.alert(t("tonePickerErrorTitle"), t("tonePickerErrorDetail"));
    }
  };

  const previewTone = async (tone: AlarmTone) => {
    await playUiTapFeedback();
    await playAlarmPreview({ ...settings, tone });
  };

  return (
    <ScreenContainer className="px-5" edges={["top", "bottom", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={styles.frame}>
        <View style={styles.header}>
          <Pressable onPress={() => { void playUiTapFeedback(); router.back(); }} style={({ pressed }) => [styles.backButton, pressed && styles.pressed]}><MaterialIcons name="arrow-forward" size={22} color="#174D9B" /></Pressable>
          <View style={styles.headerText}><Text style={styles.brand}>Jafer Guard</Text><Text style={styles.title}>{t("alarmSettingsTitle")}</Text><Text style={styles.subtitle}>{t("alarmSettingsDetail")}</Text></View>
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
          <View style={styles.currentCard}>
            <View style={styles.currentIcon}><MaterialIcons name="volume-up" size={24} color="#FFFFFF" /></View>
            <View style={styles.currentText}><Text style={styles.kicker}>{t("currentTone")}</Text><Text style={styles.currentName}>{toneName(settings.tone, settings.customToneName, t)}</Text></View>
            <PreviewButton onPress={() => void previewTone(settings.tone)} label={t("preview")} solid />
          </View>

          <Section title={t("availableTones")}>
            {TONES.map((item) => {
              const selected = settings.tone === item.tone;
              const detail = item.tone === "custom" && settings.customToneName ? settings.customToneName : t(item.detailKey);
              return <View key={item.tone} style={[styles.toneRow, selected && { borderColor: item.color, backgroundColor: `${item.color}12` }]}>
                <Pressable onPress={() => { void playUiTapFeedback(); if (item.tone === "custom") void chooseCustomTone(); else update({ tone: item.tone }); }} style={styles.toneMain}>
                  <View style={[styles.toneIcon, { backgroundColor: item.color }]}><MaterialIcons name={item.icon} size={20} color="#FFFFFF" /></View>
                  <View style={styles.toneText}><Text style={styles.toneTitle}>{toneName(item.tone, settings.customToneName, t)}</Text><Text style={styles.toneDetail}>{detail}</Text></View>
                  <View style={[styles.radio, selected && { borderColor: item.color }]}>{selected ? <View style={[styles.radioDot, { backgroundColor: item.color }]} /> : null}</View>
                </Pressable>
                <PreviewButton onPress={() => void previewTone(item.tone)} />
              </View>;
            })}
            {settings.tone === "custom" ? <Pressable onPress={() => void chooseCustomTone()} style={({ pressed }) => [styles.chooseFile, pressed && styles.pressed]}><MaterialIcons name="folder-open" size={19} color="#1FA971" /><Text style={styles.chooseFileText}>{t("chooseFile")}</Text></Pressable> : null}
          </Section>

          <Section title={t("alarmVolume")} detail={t("alarmVolumeDetail")}>
            <View style={styles.volumeRow}>{([40, 70, 100] as GuardSettings["volume"][]).map((volume) => <Pressable key={volume} onPress={() => { void playUiTapFeedback(); update({ volume }); }} style={({ pressed }) => [styles.volumeOption, settings.volume === volume && styles.volumeActive, pressed && styles.pressed]}><Text style={[styles.volumeText, settings.volume === volume && styles.volumeTextActive]}>{volume === 40 ? t("low") : volume === 70 ? t("medium") : t("high")}</Text></Pressable>)}</View>
          </Section>

          <SwitchCard icon="vibration" color="#6E56CF" title={t("vibrationTitle")} detail={t("vibrationDetail")} value={settings.vibrationEnabled} onChange={(vibrationEnabled) => update({ vibrationEnabled })} />
          <SwitchCard icon="flash-on" color="#E07A19" title={t("flashTitle")} detail={t("flashDetail")} value={settings.flashEnabled} onChange={(flashEnabled) => update({ flashEnabled })} />

          <Pressable onPress={() => void previewTone(settings.tone)} style={({ pressed }) => [styles.testButton, pressed && styles.pressed]}><MaterialIcons name="play-circle-filled" size={22} color="#FFFFFF" /><Text style={styles.testText}>{t("testCurrentAlarm")}</Text></Pressable>
        </ScrollView>
      </View>
    </ScreenContainer>
  );
}

function Section({ title, detail, children }: { title: string; detail?: string; children: ReactNode }) { return <View style={styles.section}><Text style={styles.sectionTitle}>{title}</Text>{detail ? <Text style={styles.sectionDetail}>{detail}</Text> : null}{children}</View>; }
function PreviewButton({ onPress, label, solid }: { onPress: () => void; label?: string; solid?: boolean }) { return <Pressable onPress={onPress} style={({ pressed }) => [solid ? styles.previewSolid : styles.previewOutline, pressed && styles.pressed]}><MaterialIcons name="play-arrow" size={20} color={solid ? "#FFFFFF" : "#1463FF"} />{label ? <Text style={styles.previewLabel}>{label}</Text> : null}</Pressable>; }
function SwitchCard({ icon, color, title, detail, value, onChange }: { icon: keyof typeof MaterialIcons.glyphMap; color: string; title: string; detail: string; value: boolean; onChange: (value: boolean) => void }) { return <View style={styles.switchCard}><View style={[styles.toneIcon, { backgroundColor: color }]}><MaterialIcons name={icon} size={20} color="#FFFFFF" /></View><View style={styles.toneText}><Text style={styles.toneTitle}>{title}</Text><Text style={styles.toneDetail}>{detail}</Text></View><Switch value={value} onValueChange={(next) => { void playUiTapFeedback(); onChange(next); }} trackColor={{ false: "#D4DCEA", true: `${color}88` }} thumbColor={value ? color : "#FFFFFF"} /></View>; }
function toneName(tone: AlarmTone, customName: string | null, t: (key: string) => string) { return tone === "alarm" ? t("toneAlarm") : tone === "notification" ? t("toneNotification") : tone === "ringtone" ? t("toneRingtone") : customName ?? t("toneCustom"); }

const styles = StyleSheet.create({
  frame: { flex: 1, marginVertical: 6, paddingHorizontal: 16, paddingTop: 18, borderRadius: 28, backgroundColor: "#EAF2FF", borderWidth: 2, borderColor: "#174D9B" }, header: { flexDirection: "row-reverse", alignItems: "flex-start", gap: 12, paddingBottom: 14 }, backButton: { width: 43, height: 43, borderRadius: 14, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#B8CBE8", alignItems: "center", justifyContent: "center" }, headerText: { flex: 1 }, brand: { color: "#6E56CF", fontSize: 12, fontWeight: "900", textAlign: "right" }, title: { color: "#14213D", fontSize: 23, fontWeight: "900", textAlign: "right", marginTop: 2 }, subtitle: { color: "#52647D", fontSize: 12, lineHeight: 18, textAlign: "right", marginTop: 3 }, content: { gap: 14, paddingBottom: 26 }, currentCard: { flexDirection: "row-reverse", alignItems: "center", gap: 10, padding: 14, borderRadius: 19, backgroundColor: "#DDEBFF", borderWidth: 1, borderColor: "#9BBDF2" }, currentIcon: { width: 41, height: 41, borderRadius: 13, backgroundColor: "#1463FF", alignItems: "center", justifyContent: "center" }, currentText: { flex: 1 }, kicker: { color: "#526988", fontSize: 11, fontWeight: "800", textAlign: "right" }, currentName: { color: "#162A4A", fontSize: 16, fontWeight: "900", textAlign: "right", marginTop: 2 }, previewSolid: { minHeight: 38, paddingHorizontal: 9, borderRadius: 12, gap: 2, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", backgroundColor: "#1463FF" }, previewOutline: { width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#9BBDF2" }, previewLabel: { color: "#FFFFFF", fontSize: 12, fontWeight: "900" }, section: { gap: 10, padding: 16, borderRadius: 20, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#D9E4F3" }, sectionTitle: { color: "#17233B", fontSize: 16, fontWeight: "900", textAlign: "right" }, sectionDetail: { color: "#687A92", fontSize: 12, lineHeight: 18, textAlign: "right" }, toneRow: { minHeight: 68, padding: 10, gap: 10, flexDirection: "row-reverse", alignItems: "center", borderRadius: 16, borderWidth: 1, borderColor: "#E0E7F1" }, toneMain: { flex: 1, flexDirection: "row-reverse", gap: 10, alignItems: "center" }, toneIcon: { width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center" }, toneText: { flex: 1 }, toneTitle: { color: "#1C2941", fontSize: 14, fontWeight: "900", textAlign: "right" }, toneDetail: { color: "#748096", fontSize: 11, lineHeight: 16, textAlign: "right", marginTop: 2 }, radio: { width: 20, height: 20, borderWidth: 2, borderColor: "#B7C2D0", borderRadius: 10, alignItems: "center", justifyContent: "center" }, radioDot: { width: 9, height: 9, borderRadius: 5 }, chooseFile: { minHeight: 42, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 7, borderRadius: 13, borderWidth: 1, borderColor: "#9ADBBB", backgroundColor: "#E6F7EE" }, chooseFileText: { color: "#147A52", fontSize: 13, fontWeight: "900" }, volumeRow: { flexDirection: "row-reverse", gap: 8 }, volumeOption: { flex: 1, minHeight: 45, borderRadius: 13, backgroundColor: "#F1F4FA", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#F1F4FA" }, volumeActive: { backgroundColor: "#E5EEFF", borderColor: "#1463FF" }, volumeText: { color: "#718096", fontSize: 12, fontWeight: "800" }, volumeTextActive: { color: "#1463FF" }, switchCard: { minHeight: 68, padding: 14, flexDirection: "row-reverse", alignItems: "center", gap: 11, borderRadius: 19, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#D9E4F3" }, testButton: { minHeight: 56, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 8, borderRadius: 18, backgroundColor: "#E07A19" }, testText: { color: "#FFFFFF", fontSize: 16, fontWeight: "900" }, pressed: { opacity: 0.76, transform: [{ scale: 0.98 }] },
});
