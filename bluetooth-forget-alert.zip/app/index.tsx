import AsyncStorage from "@react-native-async-storage/async-storage";
import { Redirect } from "expo-router";
import { useEffect, useState } from "react";
import { ActivityIndicator, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { ONBOARDING_KEY } from "@/lib/onboarding";

export default function EntryScreen() {
  const [isReady, setIsReady] = useState(false);
  const [isOnboardingComplete, setIsOnboardingComplete] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(ONBOARDING_KEY)
      .then((value) => setIsOnboardingComplete(value === "true"))
      .catch(() => undefined)
      .finally(() => setIsReady(true));
  }, []);

  if (!isReady) {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]}>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator size="large" color="#1463FF" />
        </View>
      </ScreenContainer>
    );
  }

  return <Redirect href={(isOnboardingComplete ? "/(tabs)" : "/onboarding") as never} />;
}
