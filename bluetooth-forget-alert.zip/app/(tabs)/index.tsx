import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, Alert, Animated, AppState, Easing, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { useFocusEffect, useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import {
  DEFAULT_SETTINGS,
  type BluetoothDeviceSummary,
  type GuardSettings,
  type MonitorState,
  listPairedDevices,
  loadSelectedDevice,
  loadSettings,
  monitorAvailable,
  playAlarmPreview,
  playUiTapFeedback,
  prepareAlarmAudio,
  requestBluetoothPermissions,
  saveSelectedDevice,
  startMonitoring,
  stopAlarmPreview,
  stopMonitoring,
} from "@/lib/bluetooth-guard";
import { findSingleConnectedDevice, reduceGuardState } from "@/lib/guard-state";
import { useLanguage } from "@/lib/language";

const statusVisuals: Record<MonitorState, { color: string; background: string; border: string; icon: keyof typeof MaterialIcons.glyphMap }> = {
  idle: { color: "#174D9B", background: "#D7E6FF", border: "#8CB5F4", icon: "shield" },
  armed: { color: "#147A52", background: "#CFF5E2", border: "#79D5A9", icon: "check-circle" },
  grace: { color: "#A8530A", background: "#FFE0B8", border: "#F5B768", icon: "schedule" },
  alerting: { color: "#B3263A", background: "#FFD5DA", border: "#F28A98", icon: "error" },
};

export default function HomeScreen() {
  const router = useRouter();
  const { t } = useLanguage();
  const [settings, setSettings] = useState<GuardSettings>(DEFAULT_SETTINGS);
  const [selectedDevice, setSelectedDevice] = useState<BluetoothDeviceSummary | null>(null);
  const [devices, setDevices] = useState<BluetoothDeviceSummary[]>([]);
  const [state, setState] = useState<MonitorState>("idle");
  const [pickerOpen, setPickerOpen] = useState(false);
  const [isLoadingDevices, setIsLoadingDevices] = useState(false);
  const flashOpacity = useRef(new Animated.Value(0)).current;
  const frameGlowOpacity = useRef(new Animated.Value(0)).current;
  const reconnectGlowOpacity = useRef(new Animated.Value(0)).current;
  const shieldPulseOpacity = useRef(new Animated.Value(0)).current;
  const previousMonitorState = useRef<MonitorState>("idle");
  const simulationTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const refreshLocalSettings = useCallback(() => {
    Promise.all([loadSettings(), loadSelectedDevice(), listPairedDevices()])
      .then(([savedSettings, savedDevice, pairedDevices]) => {
        setSettings(savedSettings);
        setDevices(pairedDevices);

        const refreshedDevice = savedDevice
          ? pairedDevices.find((device) => device.id === savedDevice.id) ?? savedDevice
          : findSingleConnectedDevice(pairedDevices);
        setSelectedDevice(refreshedDevice);

        if (!savedDevice && refreshedDevice) {
          saveSelectedDevice(refreshedDevice).catch(() => undefined);
        }
      })
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    refreshLocalSettings();
  }, [refreshLocalSettings]);

  useFocusEffect(refreshLocalSettings);

  useEffect(() => {
    const subscription = AppState.addEventListener("change", (nextState) => {
      if (nextState === "active") refreshLocalSettings();
    });
    return () => subscription.remove();
  }, [refreshLocalSettings]);

  useEffect(() => {
    if (state !== "alerting") {
      flashOpacity.stopAnimation();
      flashOpacity.setValue(0);
      return;
    }

    const flash = Animated.loop(
      Animated.sequence([
        Animated.timing(flashOpacity, { toValue: 0.22, duration: 450, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(flashOpacity, { toValue: 0.06, duration: 450, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ]),
    );
    flash.start();
    return () => {
      flash.stop();
      flashOpacity.setValue(0);
    };
  }, [flashOpacity, state]);

  useEffect(() => {
    if (state !== "armed") {
      frameGlowOpacity.stopAnimation();
      frameGlowOpacity.setValue(0);
      return;
    }

    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(frameGlowOpacity, { toValue: 0.65, duration: 1200, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(frameGlowOpacity, { toValue: 0.10, duration: 1200, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ]),
    );
    pulse.start();
    return () => {
      pulse.stop();
      frameGlowOpacity.setValue(0);
    };
  }, [frameGlowOpacity, state]);

  useEffect(() => {
    if (state !== "armed") {
      shieldPulseOpacity.stopAnimation();
      shieldPulseOpacity.setValue(0);
      return;
    }
    const pulse = Animated.loop(Animated.sequence([
      Animated.timing(shieldPulseOpacity, { toValue: 0.75, duration: 1150, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      Animated.timing(shieldPulseOpacity, { toValue: 0.08, duration: 1150, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
    ]));
    pulse.start();
    return () => { pulse.stop(); shieldPulseOpacity.setValue(0); };
  }, [shieldPulseOpacity, state]);

  useEffect(() => {
    const wasDisconnected = previousMonitorState.current === "grace" || previousMonitorState.current === "alerting";
    if (state === "armed" && wasDisconnected) {
      reconnectGlowOpacity.stopAnimation();
      reconnectGlowOpacity.setValue(0);
      Animated.sequence([
        Animated.timing(reconnectGlowOpacity, { toValue: 0.90, duration: 240, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
        Animated.timing(reconnectGlowOpacity, { toValue: 0, duration: 1050, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ]).start();
    }
    previousMonitorState.current = state;
  }, [reconnectGlowOpacity, state]);

  useEffect(() => {
    return () => {
      if (simulationTimer.current) clearTimeout(simulationTimer.current);
    };
  }, []);

  const status = useMemo(() => ({
    idle: { ...statusVisuals.idle, label: t("statusIdle"), detail: t("statusIdleDetail") },
    armed: { ...statusVisuals.armed, label: t("statusArmed"), detail: t("statusArmedDetail") },
    grace: { ...statusVisuals.grace, label: t("statusGrace"), detail: t("statusGraceDetail") },
    alerting: { ...statusVisuals.alerting, label: t("statusAlert"), detail: t("statusAlertDetail") },
  })[state], [state, t]);

  const openDevicePicker = async (autoSelectConnected = true) => {
    setIsLoadingDevices(true);
    try {
      const permitted = await requestBluetoothPermissions();
      if (!permitted) {
        Alert.alert("إذن مطلوب", "يلزم السماح بالوصول إلى أجهزة Bluetooth حتى يعرض التطبيق السماعات المقترنة.");
        return;
      }
      const paired = await listPairedDevices();
      setDevices(paired);

      const connectedDevice = findSingleConnectedDevice(paired);
      if (autoSelectConnected && connectedDevice) {
        await chooseDevice(connectedDevice);
        Alert.alert("تم اختيار السماعة", `تم اختيار ${connectedDevice.name} لأنها السماعة المتصلة حاليًا.`);
        return;
      }

      setPickerOpen(true);
    } catch {
      Alert.alert("تعذر قراءة السماعات", "تأكد من تشغيل Bluetooth ومن منح الأذونات المطلوبة.");
    } finally {
      setIsLoadingDevices(false);
    }
  };

  const chooseDevice = async (device: BluetoothDeviceSummary) => {
    setSelectedDevice(device);
    await saveSelectedDevice(device);
    setPickerOpen(false);
    if (state !== "idle") setState("armed");
  };

  const enableProtection = async () => {
    if (!selectedDevice) {
      await openDevicePicker();
      return;
    }
    try {
      const permitted = await requestBluetoothPermissions(settings.flashEnabled);
      if (!permitted) return;
      await startMonitoring(selectedDevice, settings);
      setState(reduceGuardState(state, { type: "ARM" }));
      if (selectedDevice.isPreview) {
        Alert.alert("وضع المعاينة", "ستحتاج إلى نسخة Android مبنية للتطبيق كي يراقب الهاتف سماعة حقيقية في الخلفية.");
      }
    } catch {
      Alert.alert("تعذر بدء الحماية", "تحقق من Bluetooth والأذونات، ثم حاول مرة أخرى.");
    }
  };

  const disableProtection = async () => {
    await stopMonitoring().catch(() => undefined);
    await stopAlarmPreview();
    setState(reduceGuardState(state, { type: "STOP" }));
  };

  const previewAlarm = async () => {
    await playAlarmPreview(settings);
    setState("alerting");
  };

  const simulateDisconnect = () => {
    if (simulationTimer.current) clearTimeout(simulationTimer.current);
    void prepareAlarmAudio();
    setSelectedDevice((device) => device ? { ...device, connected: false } : device);
    setState("grace");
    simulationTimer.current = setTimeout(() => {
      simulationTimer.current = null;
      void previewAlarm();
    }, settings.delaySeconds * 1000);
  };

  const simulateReconnect = async () => {
    if (simulationTimer.current) clearTimeout(simulationTimer.current);
    simulationTimer.current = null;
    await stopAlarmPreview();
    setSelectedDevice((device) => device ? { ...device, connected: true } : device);
    setState("armed");
  };

  return (
    <ScreenContainer className="px-5" edges={["top", "left", "right"]}>
      <View style={styles.appFrame}>
      <View pointerEvents="none" style={styles.frameHighlight} />
      <Animated.View pointerEvents="none" style={[styles.frameGlow, { opacity: frameGlowOpacity }]} />
      <Animated.View pointerEvents="none" style={[styles.reconnectGlow, { opacity: reconnectGlowOpacity }]} />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.topBar}>
          <View style={styles.brandBlock}>
            <View style={styles.brandIcon}>
              <MaterialIcons name="headset" size={25} color="#FFFFFF" />
              <View style={styles.lockBadge}><MaterialIcons name="lock" size={10} color="#1463FF" /></View>
            </View>
            <View style={styles.brandTitleStack}>
              <Text style={styles.brandName}>Jafer Guard</Text>
              <Text style={styles.brandSubtitle}>{t("appSubtitle")}</Text>
            </View>
          </View>
          <Pressable onPress={() => { void playUiTapFeedback(); router.push("/settings" as never); }} style={({ pressed }) => [styles.settingsButton, pressed && styles.pressed]} accessibilityLabel="الإعدادات">
            <MaterialIcons name="settings-suggest" size={27} color="#FFFFFF" />
            <Text style={styles.settingsButtonText}>{t("settings")}</Text>
          </Pressable>
        </View>

        <View style={[styles.protectionHero, { backgroundColor: status.background, borderColor: status.border }]}> 
          <View style={[styles.shieldOrbit, { borderColor: status.color }]}> 
            <Animated.View pointerEvents="none" style={[styles.shieldPulseRing, { borderColor: status.color, opacity: shieldPulseOpacity }]} />
            <View style={[styles.shieldCore, { backgroundColor: status.color }]}> 
              <MaterialIcons name={status.icon} size={36} color="#FFFFFF" />
            </View>
          </View>
          <View style={styles.heroCopy}>
            <Text style={[styles.heroKicker, { color: status.color }]}>{state === "armed" ? t("protectionOn") : t("protectionOff")}</Text>
            <Text style={styles.heroTitle}>{status.label}</Text>
            <Text style={styles.heroDetail}>{status.detail}</Text>
          </View>
        </View>

        {state === "alerting" ? (
          <View style={styles.alertCard}>
            <View style={styles.alertCopy}>
              <Text style={styles.alertTitle}>{t("alarmActive")}</Text>
              <Text style={styles.alertDetail}>{t("alarmActiveDetail")}</Text>
            </View>
            <Pressable onPress={() => { void playUiTapFeedback(); void disableProtection(); }} style={({ pressed }) => [styles.silenceButton, pressed && styles.pressed]}>
              <MaterialIcons name="volume-off" size={20} color="#FFFFFF" />
              <Text style={styles.silenceButtonText}>{t("silenceAlarm")}</Text>
            </Pressable>
          </View>
        ) : null}

        <View style={styles.deviceCard}>
          <View style={styles.deviceHeader}>
            <View style={styles.deviceGlyph}><MaterialIcons name="bluetooth-audio" size={25} color="#FFFFFF" /></View>
            <View style={styles.deviceText}>
              <Text style={styles.deviceKicker}>{t("monitoredDevice")}</Text>
              <Text style={styles.deviceName} numberOfLines={1}>{selectedDevice?.name ?? t("noDevice")}</Text>
              <Text style={[styles.deviceMeta, { color: state === "alerting" ? "#B3263A" : "#147A52" }]}>{state === "alerting" ? t("disconnectedNow") : t("lastConnectedNow")}</Text>
            </View>
            <View style={[styles.connectionChip, { backgroundColor: (state === "armed" || selectedDevice?.connected) ? "#E6F7F0" : "#F2F4F8" }]}> 
              <View style={[styles.dot, { backgroundColor: (state === "armed" || selectedDevice?.connected) ? "#1FA971" : "#A4AFBE" }]} />
              <Text style={[styles.chipText, { color: (state === "armed" || selectedDevice?.connected) ? "#18845B" : "#6E7A8C" }]}>{state === "armed" || selectedDevice?.connected ? t("connected") : t("waiting")}</Text>
            </View>
          </View>
          <Pressable onPress={() => { void playUiTapFeedback(); void openDevicePicker(false); }} style={({ pressed }) => [styles.linkButton, pressed && styles.pressed]}>
            {isLoadingDevices ? <ActivityIndicator color="#1463FF" size="small" /> : <MaterialIcons name="headset-mic" size={20} color="#1463FF" />}
            <Text style={styles.linkButtonText}>{selectedDevice ? t("changeDevice") : t("chooseConnected")}</Text>
          </Pressable>
        </View>

        <View style={styles.protectionSection}>
          {state === "armed" || state === "grace" ? <Pressable onPress={() => { void playUiTapFeedback(); void disableProtection(); }} style={({ pressed }) => [styles.disableButton, styles.fullWidth, pressed && styles.pressed]}><MaterialIcons name="shield" size={21} color="#D93C3C" /><Text style={styles.disableButtonText}>{t("disableProtection")}</Text></Pressable> : <Pressable onPress={() => { void playUiTapFeedback(); void enableProtection(); }} style={({ pressed }) => [styles.enableButton, styles.fullWidth, pressed && styles.pressed]}><MaterialIcons name="verified-user" size={22} color="#FFFFFF" /><Text style={styles.enableButtonText}>{t("enableProtection")}</Text></Pressable>}
        </View>

        <View style={styles.delaySummary}>
          <MaterialIcons name="timer" size={19} color="#E07A19" />
          <Text style={styles.delaySummaryText}>{t("delaySummary", { seconds: settings.delaySeconds })}</Text>
        </View>

        <View style={styles.responseCard}>
          <View style={styles.responseHeader}><View style={styles.responseIcon}><MaterialIcons name="bluetooth-disabled" size={21} color="#FFFFFF" /></View><Text style={styles.responseTitle}>{t("onDisconnect")}</Text></View>
          <View style={styles.responseActions}>
            <ResponseItem icon="volume-up" color="#E07A19" label={t("disconnectAlarm")} />
            <ResponseItem icon="vibration" color="#6E56CF" label={t("disconnectVibration")} />
            <ResponseItem icon="visibility" color="#D93C3C" label={t("disconnectVisual")} />
          </View>
          <View style={styles.responseDelay}><MaterialIcons name="timer" size={16} color="#A45208" /><Text style={styles.responseDelayText}>{t("disconnectAfter", { seconds: settings.delaySeconds })}</Text></View>
        </View>

        <View style={styles.toneControlCard}>
          <Pressable onPress={() => { void playUiTapFeedback(); router.push("/alarm-settings" as never); }} style={({ pressed }) => [styles.toneControlMain, pressed && styles.pressed]}><View style={styles.toneControlIcon}><MaterialIcons name="notifications-active" size={23} color="#FFFFFF" /></View><View style={styles.toneControlCopy}><Text style={styles.toneControlTitle}>{t("chooseTone")}</Text><Text style={styles.toneControlValue}>{toneLabel(settings.tone, settings.customToneName, t)}</Text></View><MaterialIcons name="chevron-left" size={24} color="#8A9BB4" /></Pressable>
          <Pressable onPress={previewAlarm} style={({ pressed }) => [styles.tonePreviewButton, pressed && styles.pressed]}><MaterialIcons name="play-circle-filled" size={21} color="#1463FF" /><Text style={styles.tonePreviewText}>{t("preview")}</Text></Pressable>
        </View>

        <Pressable onPress={previewAlarm} style={({ pressed }) => [styles.bigTestButton, pressed && styles.pressed]}><View style={styles.bigTestIcon}><MaterialIcons name="volume-up" size={25} color="#FFFFFF" /></View><View><Text style={styles.bigTestTitle}>{t("testAlarmNow")}</Text><Text style={styles.bigTestDetail}>{t("testAlarmDetail")}</Text></View></Pressable>

        {!monitorAvailable ? (
          <View style={styles.previewPanel}>
            <View style={styles.previewNote}>
              <MaterialIcons name="info-outline" size={18} color="#647084" />
              <Text style={styles.previewText}>{t("previewNotice")}</Text>
            </View>
            <View style={styles.simulationRow}>
              <Pressable onPress={() => { void playUiTapFeedback(); void simulateDisconnect(); }} style={({ pressed }) => [styles.simulateDisconnect, pressed && styles.pressed]}>
                <View style={styles.simulateDisconnectIcon}><MaterialIcons name="bluetooth-disabled" size={16} color="#FFFFFF" /></View>
                <Text style={styles.simulateDisconnectText}>{t("simulateDisconnect")}</Text>
              </Pressable>
              <Pressable onPress={() => { void playUiTapFeedback(); void simulateReconnect(); }} style={({ pressed }) => [styles.simulateReconnect, pressed && styles.pressed]}>
                <View style={styles.simulateReconnectIcon}><MaterialIcons name="bluetooth-connected" size={16} color="#FFFFFF" /></View>
                <Text style={styles.simulateReconnectText}>{t("simulateReconnect")}</Text>
              </Pressable>
            </View>
          </View>
        ) : null}
      </ScrollView>

      <Animated.View pointerEvents="none" style={[styles.flashOverlay, { opacity: flashOpacity }]} />
      </View>

      <Modal visible={pickerOpen} animationType="slide" transparent onRequestClose={() => setPickerOpen(false)}>
        <View style={styles.modalBackdrop}>
          <View style={styles.sheet}>
            <View style={styles.sheetHandle} />
            <Text style={styles.sheetTitle}>{t("chooseHeadset")}</Text>
            <Text style={styles.sheetSubtitle}>{t("pairedHeadsets")}</Text>
            {devices.length ? devices.map((device) => (
              <Pressable key={device.id} onPress={() => { void playUiTapFeedback(); void chooseDevice(device); }} style={({ pressed }) => [styles.deviceOption, pressed && styles.pressed]}>
                <View style={styles.optionIcon}><MaterialIcons name="headset" size={22} color="#FFFFFF" /></View>
                <View style={styles.optionCopy}>
                  <Text style={styles.optionTitle}>{device.name}</Text>
                  <Text style={styles.optionStatus}>{device.isPreview ? t("previewDevice") : device.connected ? t("connected") : t("paired")}</Text>
                </View>
                <MaterialIcons name="chevron-left" size={24} color="#8A95A7" />
              </Pressable>
            )) : <Text style={styles.emptyText}>{t("noPairedDevices")}</Text>}
            <Pressable onPress={() => { void playUiTapFeedback(); setPickerOpen(false); }} style={({ pressed }) => [styles.closeSheet, pressed && styles.pressed]}>
              <Text style={styles.closeSheetText}>{t("cancel")}</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}

function ActionRow({ icon, color, title, detail, onPress }: { icon: keyof typeof MaterialIcons.glyphMap; color: string; title: string; detail: string; onPress: () => void }) {
  const iconScale = useRef(new Animated.Value(1)).current;
  const animateIcon = (toValue: number, duration = 150) => {
    Animated.timing(iconScale, { toValue, duration, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  };

  return (
    <Pressable
      onPress={() => { void playUiTapFeedback(); onPress(); }}
      onPressIn={() => animateIcon(0.90, 80)}
      onPressOut={() => animateIcon(1)}
      onHoverIn={() => animateIcon(1.08)}
      onHoverOut={() => animateIcon(1)}
      style={({ pressed }) => [styles.actionRow, pressed && styles.pressed]}
    >
      <Animated.View style={{ transform: [{ scale: iconScale }] }}>
        <View style={[styles.actionIcon, { backgroundColor: color }]}><MaterialIcons name={icon} size={21} color="#FFFFFF" /></View>
      </Animated.View>
      <View style={styles.actionCopy}><Text style={styles.actionTitle}>{title}</Text><Text style={styles.actionDetail}>{detail}</Text></View>
      <MaterialIcons name="chevron-left" size={24} color="#9AA4B3" />
    </Pressable>
  );
}

function ResponseItem({ icon, color, label }: { icon: keyof typeof MaterialIcons.glyphMap; color: string; label: string }) {
  return <View style={styles.responseAction}><View style={[styles.responseActionIcon, { backgroundColor: color }]}><MaterialIcons name={icon} size={16} color="#FFFFFF" /></View><Text style={styles.responseActionText}>{label}</Text></View>;
}

function toneLabel(tone: GuardSettings["tone"], customToneName: string | null, t: (key: string) => string) {
  if (tone === "custom") return customToneName ?? t("toneCustom");
  return tone === "alarm" ? t("toneAlarm") : tone === "notification" ? t("toneNotification") : t("toneRingtone");
}

const styles = StyleSheet.create({
  appFrame: { flex: 1, marginHorizontal: 2, marginTop: 5, borderRadius: 30, overflow: "hidden", backgroundColor: "#EAF2FF", borderWidth: 3, borderColor: "#174D9B", shadowColor: "#123C7A", shadowOffset: { width: 0, height: 9 }, shadowOpacity: 0.28, shadowRadius: 16, elevation: 8 },
  frameHighlight: { position: "absolute", top: 0, right: 16, left: 16, height: 5, borderBottomLeftRadius: 6, borderBottomRightRadius: 6, backgroundColor: "#6E56CF", zIndex: 1 },
  frameGlow: { position: "absolute", top: 5, right: 5, bottom: 5, left: 5, borderRadius: 24, borderWidth: 2, borderColor: "#60A5FA", zIndex: 1 },
  reconnectGlow: { position: "absolute", top: 4, right: 4, bottom: 4, left: 4, borderRadius: 25, borderWidth: 3, borderColor: "#22C55E", zIndex: 2 },
  content: { paddingTop: 20, paddingHorizontal: 16, paddingBottom: 38, gap: 18, backgroundColor: "#EAF2FF" },
  topBar: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" },
  brandBlock: { flexDirection: "row-reverse", alignItems: "center", gap: 11 },
  brandIcon: { width: 49, height: 49, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: "#1463FF", position: "relative" },
  lockBadge: { position: "absolute", width: 19, height: 19, borderRadius: 7, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#D7E4FF", right: -4, bottom: -3, alignItems: "center", justifyContent: "center" },
  brandTitleStack: { minHeight: 42, justifyContent: "flex-start" },
  brandName: { color: "#080B12", fontFamily: "serif", fontSize: 23, fontWeight: "900", letterSpacing: 0.55, textAlign: "right" },
  brandSubtitle: { color: "#203A62", fontSize: 11, fontWeight: "800", letterSpacing: 0.15, textAlign: "right", marginTop: 2 },
  settingsButton: { width: 64, minHeight: 58, gap: 2, alignItems: "center", justifyContent: "center", borderRadius: 18, backgroundColor: "#6E56CF", borderWidth: 1.5, borderColor: "#4C35A5", shadowColor: "#392474", shadowOpacity: 0.22, shadowRadius: 6, shadowOffset: { width: 0, height: 3 }, elevation: 4 },
  settingsButtonText: { color: "#FFFFFF", fontSize: 10, fontWeight: "900" },
  protectionHero: { minHeight: 142, flexDirection: "row-reverse", alignItems: "center", gap: 17, padding: 18, borderRadius: 24, borderWidth: 1.5 },
  shieldOrbit: { width: 88, height: 88, borderRadius: 44, borderWidth: 3, alignItems: "center", justifyContent: "center" },
  shieldPulseRing: { position: "absolute", width: 103, height: 103, borderRadius: 52, borderWidth: 2 },
  shieldCore: { width: 64, height: 64, borderRadius: 32, alignItems: "center", justifyContent: "center" },
  heroCopy: { flex: 1 },
  heroKicker: { fontSize: 12, fontWeight: "900", letterSpacing: 0.5, textAlign: "right" },
  heroTitle: { color: "#17233B", fontSize: 20, fontWeight: "900", lineHeight: 27, textAlign: "right", marginTop: 3 },
  heroDetail: { color: "#44536A", fontSize: 12, lineHeight: 18, textAlign: "right", marginTop: 5 },
  alertCard: { flexDirection: "row-reverse", alignItems: "center", gap: 14, padding: 16, borderRadius: 20, backgroundColor: "#D93C3C" },
  alertCopy: { flex: 1 },
  alertTitle: { color: "#FFFFFF", fontSize: 16, fontWeight: "900", textAlign: "right" },
  alertDetail: { color: "#FFE5E7", fontSize: 12, lineHeight: 17, textAlign: "right", marginTop: 3 },
  silenceButton: { minHeight: 42, paddingHorizontal: 12, borderRadius: 13, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 6, backgroundColor: "#AB1E2B" },
  silenceButtonText: { color: "#FFFFFF", fontSize: 13, fontWeight: "900" },
  deviceCard: { padding: 18, borderWidth: 1, borderColor: "#E4E9F2", borderRadius: 22, backgroundColor: "#FFFFFF", gap: 15 },
  deviceHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 11 },
  deviceGlyph: { width: 43, height: 43, alignItems: "center", justifyContent: "center", borderRadius: 14, backgroundColor: "#1463FF" },
  deviceText: { flex: 1 },
  deviceKicker: { color: "#778397", fontSize: 11, fontWeight: "800", textAlign: "right" },
  deviceName: { color: "#17233B", fontSize: 16, fontWeight: "800", textAlign: "right", marginTop: 2 },
  deviceMeta: { fontSize: 11, fontWeight: "800", textAlign: "right", marginTop: 4 },
  connectionChip: { flexDirection: "row-reverse", alignItems: "center", gap: 5, paddingHorizontal: 8, paddingVertical: 6, borderRadius: 10 },
  dot: { width: 7, height: 7, borderRadius: 4 },
  chipText: { fontSize: 11, fontWeight: "800" },
  linkButton: { flexDirection: "row-reverse", minHeight: 46, justifyContent: "center", alignItems: "center", gap: 8, backgroundColor: "#F4F7FF", borderRadius: 14 },
  linkButtonText: { color: "#1463FF", fontWeight: "900", fontSize: 15 },
  protectionSection: { flexDirection: "row-reverse", gap: 10 },
  fullWidth: { flex: 1 },
  enableButton: { flex: 1.25, minHeight: 57, borderRadius: 18, justifyContent: "center", alignItems: "center", backgroundColor: "#1463FF", flexDirection: "row-reverse", gap: 8 },
  enableButtonText: { color: "#FFFFFF", fontSize: 16, fontWeight: "900" },
  disableButton: { flex: 1, minHeight: 57, borderRadius: 18, justifyContent: "center", alignItems: "center", backgroundColor: "#FFF1F1", flexDirection: "row-reverse", gap: 7 },
  disableButtonText: { color: "#D93C3C", fontSize: 15, fontWeight: "900" },
  delaySummary: { minHeight: 44, paddingHorizontal: 14, borderRadius: 14, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: "#FFF5E8", borderWidth: 1, borderColor: "#F5D3A4" },
  delaySummaryText: { color: "#A45208", fontSize: 13, fontWeight: "800" },
  responseCard: { gap: 13, padding: 16, borderRadius: 20, borderWidth: 1, borderColor: "#D9E3F2", backgroundColor: "#FFFFFF" },
  responseHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 10 },
  responseIcon: { width: 40, height: 40, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: "#E07A19" },
  responseTitle: { flex: 1, color: "#17233B", fontSize: 15, fontWeight: "900", textAlign: "right" },
  responseActions: { flexDirection: "row-reverse", justifyContent: "space-between", gap: 8 },
  responseAction: { flex: 1, alignItems: "center", gap: 5 },
  responseActionIcon: { width: 31, height: 31, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  responseActionText: { color: "#52647A", fontSize: 10, fontWeight: "800", textAlign: "center" },
  responseDelay: { minHeight: 32, paddingHorizontal: 10, borderRadius: 10, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 6, backgroundColor: "#FFF5E8" },
  responseDelayText: { color: "#A45208", fontSize: 11, fontWeight: "900" },
  toneControlCard: { borderWidth: 1, borderColor: "#DDD8F6", borderRadius: 20, backgroundColor: "#FFFFFF", overflow: "hidden" },
  toneControlMain: { minHeight: 73, paddingHorizontal: 15, flexDirection: "row-reverse", alignItems: "center", gap: 11 },
  toneControlIcon: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: "#6E56CF" },
  toneControlCopy: { flex: 1 },
  toneControlTitle: { color: "#1F1A3C", fontSize: 15, fontWeight: "900", textAlign: "right" },
  toneControlValue: { color: "#685CA0", fontSize: 12, fontWeight: "800", textAlign: "right", marginTop: 3 },
  tonePreviewButton: { minHeight: 42, borderTopWidth: 1, borderTopColor: "#EEEAFB", backgroundColor: "#F8F6FF", flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 6 },
  tonePreviewText: { color: "#1463FF", fontSize: 13, fontWeight: "900" },
  bigTestButton: { minHeight: 70, paddingHorizontal: 17, borderRadius: 22, flexDirection: "row-reverse", alignItems: "center", gap: 12, backgroundColor: "#E07A19", shadowColor: "#A45208", shadowOpacity: 0.22, shadowRadius: 8, shadowOffset: { width: 0, height: 4 }, elevation: 4 },
  bigTestIcon: { width: 40, height: 40, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center" },
  bigTestTitle: { color: "#FFFFFF", fontSize: 16, fontWeight: "900", textAlign: "right" },
  bigTestDetail: { color: "#FFF2E3", fontSize: 11, fontWeight: "700", textAlign: "right", marginTop: 2 },
  actionList: { borderWidth: 1, borderColor: "#E4E9F2", borderRadius: 22, overflow: "hidden", backgroundColor: "#FFFFFF" },
  actionRow: { minHeight: 76, flexDirection: "row-reverse", alignItems: "center", gap: 12, paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: "#EEF1F5" },
  actionIcon: { width: 40, height: 40, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  actionCopy: { flex: 1 },
  actionTitle: { color: "#17233B", fontSize: 15, fontWeight: "900", textAlign: "right" },
  actionDetail: { color: "#768397", fontSize: 12, textAlign: "right", marginTop: 3 },
  previewPanel: { gap: 10 },
  previewNote: { flexDirection: "row-reverse", gap: 8, alignItems: "flex-start", backgroundColor: "#F1F4F8", borderRadius: 14, padding: 13 },
  previewText: { flex: 1, color: "#647084", fontSize: 12, lineHeight: 17, textAlign: "right" },
  simulationRow: { flexDirection: "row-reverse", gap: 10 },
  simulateDisconnect: { flex: 1, minHeight: 46, flexDirection: "row-reverse", gap: 7, alignItems: "center", justifyContent: "center", borderRadius: 14, borderWidth: 1, borderColor: "#F3C8CD", backgroundColor: "#FFF7F7" },
  simulateDisconnectIcon: { width: 26, height: 26, borderRadius: 9, backgroundColor: "#D93C3C", alignItems: "center", justifyContent: "center" },
  simulateDisconnectText: { color: "#C8323A", fontSize: 12, fontWeight: "900" },
  simulateReconnect: { flex: 1, minHeight: 46, flexDirection: "row-reverse", gap: 7, alignItems: "center", justifyContent: "center", borderRadius: 14, borderWidth: 1, borderColor: "#BEE8D4", backgroundColor: "#F1FBF6" },
  simulateReconnectIcon: { width: 26, height: 26, borderRadius: 9, backgroundColor: "#1FA971", alignItems: "center", justifyContent: "center" },
  simulateReconnectText: { color: "#18845B", fontSize: 12, fontWeight: "900" },
  flashOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: "#D93C3C" },
  modalBackdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(11,18,32,0.35)" },
  sheet: { backgroundColor: "#FFFFFF", paddingHorizontal: 20, paddingTop: 12, paddingBottom: 28, borderTopLeftRadius: 28, borderTopRightRadius: 28, gap: 10 },
  sheetHandle: { width: 42, height: 5, borderRadius: 5, backgroundColor: "#D5DAE3", alignSelf: "center", marginBottom: 6 },
  sheetTitle: { color: "#0B1220", fontSize: 21, fontWeight: "900", textAlign: "right" },
  sheetSubtitle: { color: "#718096", fontSize: 13, textAlign: "right", marginBottom: 8 },
  deviceOption: { minHeight: 70, flexDirection: "row-reverse", alignItems: "center", gap: 12, borderWidth: 1, borderColor: "#E7EBF1", borderRadius: 17, padding: 12 },
  optionIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: "#1463FF", alignItems: "center", justifyContent: "center" },
  optionCopy: { flex: 1 },
  optionTitle: { color: "#17233B", fontSize: 15, fontWeight: "800", textAlign: "right" },
  optionStatus: { color: "#718096", fontSize: 12, textAlign: "right", marginTop: 2 },
  emptyText: { color: "#718096", textAlign: "center", paddingVertical: 18 },
  closeSheet: { alignItems: "center", minHeight: 48, justifyContent: "center", marginTop: 6 },
  closeSheetText: { color: "#647084", fontSize: 15, fontWeight: "800" },
  pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
});
