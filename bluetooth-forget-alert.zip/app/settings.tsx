import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useState } from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Switch, Text, View } from "react-native";
import { Stack, useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { DEFAULT_SETTINGS, type AlarmTone, type GuardSettings, loadSettings, pickCustomTone, playAlarmPreview, playUiTapFeedback, saveSettings } from "@/lib/bluetooth-guard";
import { useLanguage } from "@/lib/language";
import { ONBOARDING_KEY } from "@/lib/onboarding";

const delayOptions: GuardSettings["delaySeconds"][] = [3, 5, 10, 20, 30];
const volumeOptions: GuardSettings["volume"][] = [40, 70, 100];
const toneOptions: { value: AlarmTone; label: string; description: string }[] = [
  { value: "alarm", label: "جرس المنبّه", description: "يستخدم نغمة المنبّه المضبوطة في الجوال" },
  { value: "notification", label: "نغمة الإشعار", description: "يستخدم نغمة الإشعارات المضبوطة في الجوال" },
  { value: "ringtone", label: "نغمة الرنين", description: "يستخدم نغمة الرنين المضبوطة في الجوال" },
  { value: "custom", label: "نغمة من الجهاز", description: "اختر ملفًا صوتيًا مرتفعًا من جهازك" },
];

export default function SettingsScreen() {
  const router = useRouter();
  const { language, setLanguage, t } = useLanguage();
  const [settings, setSettings] = useState<GuardSettings>(DEFAULT_SETTINGS);

  useEffect(() => {
    loadSettings().then(setSettings).catch(() => undefined);
  }, []);

  const update = (patch: Partial<GuardSettings>) => {
    const next = { ...settings, ...patch };
    setSettings(next);
    saveSettings(next).catch(() => undefined);
  };

  const chooseCustomTone = async () => {
    try {
      const customTone = await pickCustomTone();
      if (!customTone) return;
      update({ tone: "custom", customToneUri: customTone.uri, customToneName: customTone.name });
    } catch {
      Alert.alert("تعذر اختيار النغمة", "تأكد من اختيار ملف صوتي صالح ثم حاول مرة أخرى.");
    }
  };

  const replayIntroduction = async () => {
    await playUiTapFeedback();
    await AsyncStorage.removeItem(ONBOARDING_KEY);
    router.replace("/onboarding" as never);
  };

  return (
    <ScreenContainer className="px-5" edges={["top", "left", "right", "bottom"]}>
      <Stack.Screen options={{ headerShown: false }} />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Pressable onPress={() => { void playUiTapFeedback(); router.back(); }} style={({ pressed }) => [styles.backButton, pressed && styles.pressed]}>
            <Text style={styles.backText}>‹</Text>
          </Pressable>
          <View>
            <Text style={styles.eyebrow}>Jafer Guard</Text>
            <Text style={styles.title}>{t("settings")}</Text>
          </View>
        </View>

        <Section title={t("language")} description="">
          <View style={styles.optionRow}>
            <Pill active={language === "ar"} onPress={() => void setLanguage("ar")} label={t("arabic")} />
            <Pill active={language === "en"} onPress={() => void setLanguage("en")} label={t("english")} />
          </View>
        </Section>

        <View style={styles.permissionCard}>
          <View style={styles.permissionIcon}><Text style={styles.permissionIconText}>i</Text></View>
          <View style={styles.permissionCopy}>
            <Text style={styles.permissionTitle}>{t("permissionInfo")}</Text>
            <Text style={styles.permissionDescription}>{t("permissionDetail")}</Text>
          </View>
        </View>

        <Section title={t("delayTitle")} description={t("delayDetail")}>
          <View style={styles.optionRow}>
            {delayOptions.map((delay) => (
              <Pill key={delay} active={settings.delaySeconds === delay} onPress={() => update({ delaySeconds: delay })} label={`${delay} ث`} />
            ))}
          </View>
        </Section>

        <Section title={t("toneTitle")} description={t("toneDetail")}>
          <View style={styles.toneStack}>
            {toneOptions.map((tone) => (
              <Pressable
                key={tone.value}
                onPress={() => { void playUiTapFeedback(); tone.value === "custom" ? void chooseCustomTone() : update({ tone: tone.value }); }}
                style={({ pressed }) => [styles.toneOption, settings.tone === tone.value && styles.toneOptionActive, pressed && styles.pressed]}
              >
                <View style={styles.radio}>{settings.tone === tone.value ? <View style={styles.radioDot} /> : null}</View>
                <View style={styles.toneCopy}>
                  <Text style={styles.toneLabel}>{tone.value === "alarm" ? t("toneAlarm") : tone.value === "notification" ? t("toneNotification") : tone.value === "ringtone" ? t("toneRingtone") : t("toneCustom")}</Text>
                  <Text style={styles.toneDescription}>{tone.value === "custom" && settings.customToneName ? settings.customToneName : tone.description}</Text>
                </View>
              </Pressable>
            ))}
          </View>
        </Section>

        <Section title={t("volumeTitle")} description={t("volumeDetail")}>
          <View style={styles.optionRow}>
            {volumeOptions.map((volume) => (
              <Pill key={volume} active={settings.volume === volume} onPress={() => update({ volume })} label={`${volume}%`} />
            ))}
          </View>
        </Section>

        <View style={styles.switchCard}>
          <View style={styles.switchCopy}>
            <Text style={styles.switchTitle}>{t("vibrationTitle")}</Text>
            <Text style={styles.switchDescription}>{t("vibrationDetail")}</Text>
          </View>
          <Switch
            value={settings.vibrationEnabled}
            onValueChange={(vibrationEnabled) => { void playUiTapFeedback(); update({ vibrationEnabled }); }}
            trackColor={{ false: "#D7DCE6", true: "#8BB3FF" }}
            thumbColor={settings.vibrationEnabled ? "#1463FF" : "#FFFFFF"}
          />
        </View>

        <Pressable onPress={() => { void playUiTapFeedback(); void playAlarmPreview(settings); }} style={({ pressed }) => [styles.testButton, pressed && styles.pressed]}>
          <Text style={styles.testButtonText}>{t("testCurrentAlarm")}</Text>
        </Pressable>

        <Pressable onPress={() => void replayIntroduction()} style={({ pressed }) => [styles.replayIntroButton, pressed && styles.pressed]}>
          <Text style={styles.replayIntroText}>{t("replayIntroduction")}</Text>
        </Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}

function Section({ title, description, children }: { title: string; description: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <Text style={styles.sectionDescription}>{description}</Text>
      {children}
    </View>
  );
}

function Pill({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={() => { void playUiTapFeedback(); onPress(); }} style={({ pressed }) => [styles.pill, active && styles.pillActive, pressed && styles.pressed]}>
      <Text style={[styles.pillText, active && styles.pillTextActive]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 14, paddingBottom: 32, gap: 24 },
  header: { flexDirection: "row-reverse", alignItems: "center", gap: 14 },
  backButton: { width: 44, height: 44, alignItems: "center", justifyContent: "center", backgroundColor: "#F1F4FA", borderRadius: 14 },
  backText: { color: "#0B1220", fontSize: 34, lineHeight: 34, marginTop: -5 },
  eyebrow: { color: "#1463FF", fontSize: 13, fontWeight: "800", letterSpacing: 0.4, textAlign: "right" },
  title: { color: "#0B1220", fontSize: 28, fontWeight: "800", textAlign: "right", marginTop: 1 },
  permissionCard: { flexDirection: "row-reverse", alignItems: "flex-start", gap: 12, backgroundColor: "#E9F0FF", borderWidth: 1, borderColor: "#C9D9FF", borderRadius: 20, padding: 16 },
  permissionIcon: { width: 28, height: 28, borderRadius: 14, backgroundColor: "#1463FF", alignItems: "center", justifyContent: "center" },
  permissionIconText: { color: "#FFFFFF", fontSize: 17, fontWeight: "900" },
  permissionCopy: { flex: 1 },
  permissionTitle: { color: "#123A8C", fontSize: 15, fontWeight: "900", textAlign: "right" },
  permissionDescription: { color: "#365686", fontSize: 12, lineHeight: 18, textAlign: "right", marginTop: 3 },
  section: { backgroundColor: "#FFFFFF", borderColor: "#E4E9F2", borderWidth: 1, borderRadius: 20, padding: 18, gap: 10 },
  sectionTitle: { color: "#101A2D", fontSize: 17, fontWeight: "800", textAlign: "right" },
  sectionDescription: { color: "#647084", fontSize: 13, lineHeight: 19, textAlign: "right" },
  optionRow: { flexDirection: "row-reverse", gap: 8, marginTop: 4 },
  pill: { flex: 1, minHeight: 44, alignItems: "center", justifyContent: "center", borderRadius: 12, backgroundColor: "#F1F4FA", borderWidth: 1, borderColor: "#F1F4FA" },
  pillActive: { backgroundColor: "#E9F0FF", borderColor: "#1463FF" },
  pillText: { color: "#667287", fontWeight: "800", fontSize: 13 },
  pillTextActive: { color: "#1463FF" },
  toneStack: { gap: 9, marginTop: 3 },
  toneOption: { flexDirection: "row-reverse", alignItems: "center", borderWidth: 1, borderColor: "#E4E9F2", borderRadius: 15, padding: 13, gap: 12 },
  toneOptionActive: { borderColor: "#1463FF", backgroundColor: "#F4F7FF" },
  radio: { width: 21, height: 21, borderRadius: 12, borderWidth: 2, borderColor: "#1463FF", alignItems: "center", justifyContent: "center" },
  radioDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: "#1463FF" },
  toneCopy: { flex: 1 },
  toneLabel: { color: "#1C2941", fontSize: 15, fontWeight: "800", textAlign: "right" },
  toneDescription: { color: "#718096", fontSize: 12, textAlign: "right", marginTop: 2 },
  switchCard: { flexDirection: "row-reverse", alignItems: "center", backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E4E9F2", borderRadius: 20, padding: 18, gap: 18 },
  switchCopy: { flex: 1 },
  switchTitle: { color: "#101A2D", fontSize: 16, fontWeight: "800", textAlign: "right" },
  switchDescription: { color: "#647084", fontSize: 12, lineHeight: 18, textAlign: "right", marginTop: 4 },
  testButton: { minHeight: 54, borderRadius: 17, borderWidth: 1.5, borderColor: "#1463FF", justifyContent: "center", alignItems: "center" },
  testButtonText: { color: "#1463FF", fontSize: 16, fontWeight: "800" },
  replayIntroButton: { minHeight: 50, borderRadius: 16, justifyContent: "center", alignItems: "center", backgroundColor: "#EFF4FC" },
  replayIntroText: { color: "#52647A", fontSize: 14, fontWeight: "800" },
  pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
});
