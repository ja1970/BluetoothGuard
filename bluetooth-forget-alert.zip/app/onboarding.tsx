import AsyncStorage from "@react-native-async-storage/async-storage";
import { MaterialIcons } from "@expo/vector-icons";
import { Stack, useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { ONBOARDING_KEY, ONBOARDING_STEP_COUNT, nextOnboardingStep } from "@/lib/onboarding";
import { useLanguage } from "@/lib/language";

type Step = {
  icon: keyof typeof MaterialIcons.glyphMap;
  color: string;
  pale: string;
  title: string;
  detail: string;
};

export default function OnboardingScreen() {
  const router = useRouter();
  const { t } = useLanguage();
  const [step, setStep] = useState(0);

  const steps = useMemo<Step[]>(() => [
    { icon: "security", color: "#1463FF", pale: "#DCEBFF", title: t("onboardingWelcomeTitle"), detail: t("onboardingWelcomeDetail") },
    { icon: "headset-mic", color: "#1463FF", pale: "#DCEBFF", title: t("onboardingStepDeviceTitle"), detail: t("onboardingStepDeviceDetail") },
    { icon: "notifications-active", color: "#E07A19", pale: "#FFF0DD", title: t("onboardingStepAlertTitle"), detail: t("onboardingStepAlertDetail") },
    { icon: "verified-user", color: "#1FA971", pale: "#DDF7EB", title: t("onboardingStepProtectTitle"), detail: t("onboardingStepProtectDetail") },
  ], [t]);
  const current = steps[step];
  const isLastStep = step === ONBOARDING_STEP_COUNT - 1;

  const finish = async () => {
    await AsyncStorage.setItem(ONBOARDING_KEY, "true");
    router.replace("/(tabs)" as never);
  };

  return (
    <ScreenContainer className="px-5" edges={["top", "bottom", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={styles.frame}>
        <View style={styles.topRow}>
          <View style={styles.brandMark}><MaterialIcons name="security" size={23} color="#FFFFFF" /></View>
        </View>

        <View style={styles.progressRow}>
          {steps.map((_, index) => <View key={index} style={[styles.progressDot, index <= step && styles.progressDotActive]} />)}
        </View>

        <View style={styles.hero}>
          <View style={[styles.iconOrbit, { borderColor: current.color, backgroundColor: current.pale }]}>
            <View style={[styles.iconCore, { backgroundColor: current.color }]}>
              <MaterialIcons name={current.icon} size={47} color="#FFFFFF" />
            </View>
          </View>
          <Text style={styles.stepCount}>{t("onboardingStepCount", { current: step + 1, total: ONBOARDING_STEP_COUNT })}</Text>
          <Text style={styles.title}>{current.title}</Text>
          <Text style={styles.detail}>{current.detail}</Text>
        </View>

        <View style={styles.stepList}>
          {steps.map((item, index) => (
            <View key={item.title} style={[styles.stepListItem, index === step && { borderColor: item.color, backgroundColor: item.pale }]}>
              <View style={[styles.stepListIcon, { backgroundColor: item.color }]}><MaterialIcons name={item.icon} size={17} color="#FFFFFF" /></View>
              <Text style={styles.stepListText}>{item.title}</Text>
              {index < step ? <MaterialIcons name="check-circle" size={20} color="#1FA971" /> : null}
            </View>
          ))}
        </View>

        <Pressable onPress={() => isLastStep ? void finish() : setStep(nextOnboardingStep(step))} style={({ pressed }) => [styles.primaryButton, { backgroundColor: current.color }, pressed && styles.pressed]}>
          <Text style={styles.primaryText}>{isLastStep ? t("onboardingFinish") : t("onboardingNext")}</Text>
          <MaterialIcons name={isLastStep ? "arrow-back" : "arrow-forward"} size={21} color="#FFFFFF" />
        </Pressable>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  frame: { flex: 1, marginVertical: 8, padding: 20, borderRadius: 30, backgroundColor: "#EAF2FF", borderWidth: 2, borderColor: "#174D9B", justifyContent: "space-between" },
  topRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "flex-start" },
  brandMark: { width: 46, height: 46, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: "#6E56CF" },
  progressRow: { flexDirection: "row-reverse", justifyContent: "center", gap: 8, marginTop: 8 },
  progressDot: { height: 7, width: 30, borderRadius: 4, backgroundColor: "#C2D1E8" },
  progressDotActive: { backgroundColor: "#1463FF" },
  hero: { alignItems: "center", paddingHorizontal: 18 },
  iconOrbit: { width: 132, height: 132, borderRadius: 66, borderWidth: 3, justifyContent: "center", alignItems: "center", marginBottom: 24 },
  iconCore: { width: 94, height: 94, borderRadius: 47, justifyContent: "center", alignItems: "center" },
  stepCount: { color: "#587295", fontSize: 13, fontWeight: "900", letterSpacing: 0.35 },
  title: { color: "#111827", fontSize: 25, lineHeight: 34, fontWeight: "900", textAlign: "center", marginTop: 10 },
  detail: { color: "#4A5D78", fontSize: 15, lineHeight: 23, textAlign: "center", marginTop: 9 },
  stepList: { gap: 9 },
  stepListItem: { minHeight: 54, paddingHorizontal: 13, flexDirection: "row-reverse", alignItems: "center", gap: 10, borderWidth: 1, borderColor: "#D2DDEB", borderRadius: 16, backgroundColor: "#FFFFFF" },
  stepListIcon: { width: 30, height: 30, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  stepListText: { flex: 1, color: "#24334B", fontSize: 13, fontWeight: "800", textAlign: "right" },
  primaryButton: { minHeight: 56, borderRadius: 18, flexDirection: "row-reverse", justifyContent: "center", alignItems: "center", gap: 9 },
  primaryText: { color: "#FFFFFF", fontSize: 16, fontWeight: "900" },
  pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
});
